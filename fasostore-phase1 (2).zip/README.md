# FasoStore — phase 1 : architecture et préparation

**Créez. Vendez. Développez votre commerce en ligne.**

Ce dépôt contient le vrai socle exécutable de FasoStore, pas une boutique terminée. Il se lance avec deux applications distinctes : une interface **Next.js / React / TypeScript** et une **API Fastify / TypeScript**. L'interface teste réellement l'API via un relais côté serveur. Les modes clair et sombre fonctionnent et sont mémorisés dans le navigateur.

## Ce qui existe réellement

- Une interface responsive en français, avec navigation et thème clair/sombre.
- Une API indépendante avec `GET /healthz` et un relais Next.js `GET /api/health` : aucune adresse interne n'est envoyée au navigateur.
- Des en-têtes de sécurité de base, des erreurs génériques et une limite de requêtes **locale à l'instance** pour l'API de santé.
- Six tests automatisés : routes de santé, limitation locale, gestion des erreurs et filtrage du relais ; vérification TypeScript et compilation de production.
- Un workflow GitHub Actions qui relance ces contrôles et `npm audit`.

**Pas encore implémentés :** PostgreSQL, isolation des boutiques, inscription, connexion, 2FA, gestion des rôles, comptes, boutique, produits, commandes, paiements, stockage de fichiers, sauvegardes, assistant IA et déploiement de production. Ne pas utiliser cette phase pour de vraies données clients ou pour encaisser de l'argent. Une vérification de santé n'est pas un audit de sécurité.

## Structure des fichiers

```text
fasostore/
├── apps/
│   ├── web/              # Interface Next.js et relais serveur /api/health
│   └── api/              # API Fastify indépendante et ses tests
├── docs/                 # Architecture, sécurité, mise en route Android
├── .devcontainer/        # Configuration des futurs Codespaces
├── .github/workflows/    # Tests automatiques GitHub Actions
├── package.json          # Commandes communes, espaces de travail npm
├── package-lock.json     # Versions de dépendances verrouillées
└── .nvmrc                # Node.js 24
```

- [Instructions détaillées Android](docs/DEMARRAGE_ANDROID.md)
- [Architecture et séparation multi-boutiques prévue](docs/ARCHITECTURE.md)
- [Sécurité : en place, à faire et critères de validation](docs/SECURITE.md)
- [Préparation du déploiement](docs/DEPLOIEMENT.md)

## Commandes principales

Dans un environnement de développement avec Node.js 24 :

```bash
npm ci
npm run check
npm audit --audit-level=high
npm run dev
```

`npm run check` lance la vérification TypeScript, les tests puis la compilation des deux applications. `npm run dev` démarre les deux serveurs : l'interface sur le port 3000 et l'API sur le port 4000. Ouvrez le **port 3000**, pas une adresse localhost sur le téléphone. Le navigateur utilise des URL relatives ; seul le serveur Next.js appelle l'API via son adresse interne.

Par défaut en développement, l'API est joignable **depuis le serveur Next.js** à `http://127.0.0.1:4000`. En production, `API_INTERNAL_URL` est obligatoire côté serveur, sans préfixe `NEXT_PUBLIC_`. Aucun mot de passe ou clé n'est requis pendant cette phase.

## Validation avant phase 2

1. `npm run check` se termine sans erreur et les six tests passent.
2. Sur la page ouverte depuis le port 3000, la carte **API FasoStore** indique « Connectée ». Son bouton d'actualisation fonctionne.
3. Le bouton de thème passe du mode clair au mode sombre et reste mémorisé après rechargement.
4. La base et les comptes sont indiqués comme **prévus**, pas comme déjà en service.
5. Le projet est enregistré dans votre dépôt GitHub privé. Ensuite seulement, commencer la base PostgreSQL en phase 2.

> Les commandes `npm audit` et les tests décrits vérifient uniquement un périmètre limité. Ils ne certifient ni la sécurité complète ni la capacité à servir des milliers de boutiques.
