# Architecture recommandée de FasoStore

## 1. Périmètre livré en phase 1

```text
Navigateur Android ou ordinateur
       │ HTTPS / même origine
       ▼
Interface Next.js : apps/web
       │ route serveur /api/health
       │ HTTP interne en développement
       ▼
API Fastify : apps/api
       └── GET /healthz
```

La route web appelle l'API côté serveur ; le navigateur n'appelle pas `127.0.0.1:4000`. Le résultat indique seulement que l'API répond. Il n'y a aucune base de données ni information commerciale dans ce socle.

## 2. Architecture cible — pas encore réalisée

```text
Navigateur vendeur / acheteur / administrateur
       │ HTTPS
       ▼
Next.js (pages, SEO, relais serveur/BFF, origine contrôlée)
       │ réseau privé ou TLS entre services
       ▼
API Fastify (validation, authentification, permissions, logique métier)
       ├── PostgreSQL (transactions, migrations, politiques RLS)
       ├── Stockage objet compatible S3 (images et documents)
       ├── File/worker et notifications (si nécessaires)
       └── Prestataires paiement/livraison (contrats et pays à vérifier)
```

Les webhooks des prestataires passeront par un point d'entrée HTTPS contrôlé, puis seront vérifiés par l'API avec les octets bruts et la signature du prestataire ; ils ne doivent pas rendre l'API interne entière publique. Les secrets restent côté serveur. Les services peuvent être déployés séparément depuis le même dépôt.

## 3. Séparation entre boutiques — conception pour la phase 2

- `users` représente les personnes ; `tenants` les boutiques ; `memberships` associe une personne et son rôle à une boutique. Une personne pourra être membre de plusieurs boutiques.
- Les tables métier propres à une boutique posséderont un `tenant_id` non nul ; les requêtes sont toujours contextualisées. Des clés étrangères composites incluant `tenant_id` empêcheront de lier accidentellement des données de deux boutiques.
- Le contexte de boutique viendra d'une boutique résolue par le serveur **et** d'une appartenance/permission vérifiée. Un `tenant_id` ou un en-tête fourni par le navigateur ne sera jamais considéré comme une autorisation.
- Utiliser PostgreSQL Row Level Security avec `FORCE ROW LEVEL SECURITY`, des politiques « refuser par défaut », et un rôle d'exécution non propriétaire, non superutilisateur et sans `BYPASSRLS`. Le rôle de migration est distinct. Aucun secret ni rôle propriétaire côté navigateur.
- Dans chaque transaction, poser l'identité de boutique avec `set_config(..., true)` / `SET LOCAL`, puis exécuter toutes les requêtes sur la **même connexion de transaction**. En cas d'erreur : rollback. Tester l'absence de fuite de contexte dans le pool de connexions, y compris après erreur.
- L'accès de démarrage à l'identité et aux appartenances exige un chemin explicite limité ; les opérations d'administration inter-boutiques exigent des permissions particulières, la MFA et un audit. Ne pas contourner silencieusement RLS.
- La vitrine publique aura un chemin de lecture/achat limité, distinct d'un accès vendeur, et une résolution du domaine ou du slug contrôlée par le serveur. Les domaines personnalisés et certificats seront traités ultérieurement.

Le choix et la configuration de PostgreSQL seront validés par des tests d'accès croisés réels en phase 2. Ces garanties ne sont pas actives en phase 1.

## 4. Modèle de données envisagé

Outre les utilisateurs, boutiques et appartenances : sessions, catalogue, variantes, images, stocks et mouvements, clients, commandes et lignes de commande, paiements, événements de webhook, zones et tarifs de livraison, abonnements et journal d'audit. Les prix seront stockés dans l'unité monétaire minimale, sans nombres flottants pour les calculs financiers ; la devise sera explicite. Les migrations versionnées et transactions seront introduites avec la base.

## 5. Choix des services depuis Android

- GitHub et GitHub Codespaces : dépôt privé et environnement de développement dans Chrome.
- Neon ou un autre PostgreSQL managé : à sélectionner et configurer en phase 2 ; accès TLS et rôles restreints.
- Render ou hébergeur équivalent : interface web et API indépendante, avec réseau privé si disponible ; choix du plan et coût à confirmer avant production.
- Stockage compatible S3, par exemple Cloudflare R2 : à configurer uniquement lors de l'ajout des fichiers. Validation du type réel/taille, URLs courtes, domaine d'images isolé et contrôle des contenus.

Les offres gratuites ont des limites ; elles ne garantissent pas les sauvegardes, la disponibilité ou la capacité nécessaires à une exploitation commerciale. Aucune de ces connexions cloud n'est configurée dans la phase 1.

## 6. Évolutivité

Le découpage permet une montée en charge, mais ne constitue pas une preuve de capacité. Prévoir des index par boutique, pagination, connexions mutualisées, tâches asynchrones, métriques, alertes et tests de charge réalistes ; dimensionner seulement après mesure. La limite actuelle de l'API est locale à un processus et ne remplace pas un limiteur partagé ou une politique fiable de proxy en production.
