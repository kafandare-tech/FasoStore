# Sécurité — état réel et travail restant

## Présent dans le socle de phase 1

- Réponses de santé limitées et non mises en cache ; le relais n'expose ni URL interne ni détails d'erreur en cas de panne.
- En-têtes de base sur l'API et le site, `X-Powered-By` désactivé sur Next.js, identifiants de requête côté API et erreurs génériques.
- Limite de 120 requêtes/minute **par processus** sur la route de santé, testée. `trustProxy` est désactivé : derrière un proxy, cela ne représente pas nécessairement l'adresse du visiteur.
- Schéma de validation du port au démarrage, limitation de taille des requêtes, versions verrouillées et audit des dépendances.
- Aucun mot de passe, aucune clé API ni aucune donnée réelle dans le dépôt d'origine.

Ces mesures ne rendent pas le projet prêt pour la production. Les tests et `npm audit` couvrent un périmètre restreint et les résultats évoluent dans le temps.

## Obligatoire avant d'exposer des comptes ou des données réelles

1. **Identités et sessions** : Argon2id, paramètres adaptés et réévalués, tokens aléatoires de session conservés hachés, cookies `Secure`, `HttpOnly`, `SameSite` adaptés, rotation et révocation. Pour les cookies hôte, privilégier le préfixe `__Host-` ; traiter explicitement les sessions entre domaines de boutique.
2. **Deuxième facteur** : TOTP ou solution validée, secrets chiffrés côté serveur, codes de récupération protégés et procédure de récupération. MFA renforcée pour les administrateurs de plateforme.
3. **Permissions et isolation** : contrôles côté serveur sur chaque opération, appartenance vérifiée, politiques PostgreSQL RLS, rôle applicatif non propriétaire et tests négatifs entre boutiques ; détails dans `ARCHITECTURE.md`.
4. **CSRF et origines** : contrôle d'origine strict et protection CSRF pour les opérations utilisant des cookies ; CORS limité si nécessaire, jamais un `*` avec des identifiants. Ne pas mettre de secret dans les URL.
5. **Abus** : limitation distribuée et politique de proxy de confiance explicitement configurée avant les routes sensibles ; quotas d'inscription, connexion, MFA, mots de passe et webhooks. Ne jamais faire confiance sans filtre aux en-têtes `X-Forwarded-*`.
6. **Entrées et sorties** : schémas validés côté serveur, SQL paramétré, échappement XSS, politique CSP adaptée à Next.js, contrôle des téléversements, types et tailles, isolation des fichiers. Journaux sans secrets ni données excessives.
7. **Paiements** : vérification de la signature avec corps brut et clés gardées côté serveur, expiration/rejeu, idempotence et déduplication des événements, écritures transactionnelles, tests en sandbox. Aucun moyen de paiement ne sera présenté comme actif avant contrat et tests réels.
8. **Exploitation** : TLS, secrets dans le gestionnaire de l'hébergeur, rôles minimum, mise à jour des dépendances, alertes, sauvegardes chiffrées, politique de rétention et tests réguliers de restauration.
9. **Validation indépendante** : tests de sécurité, d'autorisations et de charge, analyse des dépendances et revue/audit professionnel avant lancement commercial.

## Incidents

Si un secret est commité ou envoyé par erreur : le révoquer/faire tourner immédiatement auprès du fournisseur, puis traiter son retrait de l'historique. Effacer seulement le fichier dans un nouveau commit ne suffit pas. Ne collez jamais de secret dans les tickets, journaux ou messages d'aide.
