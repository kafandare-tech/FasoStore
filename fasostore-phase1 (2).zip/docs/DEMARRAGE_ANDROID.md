# Phase 1 — guide Android pas à pas

Tout se fait avec Chrome sur Android et un compte GitHub personnel. Un clavier Bluetooth est facultatif. La création des comptes GitHub/Neon/Render, la saisie de leurs identifiants et toute validation de paiement restent sous votre contrôle. Ne partagez jamais vos mots de passe, clés ou codes de récupération dans la conversation.

## 1. Préparer le téléphone et GitHub

1. Télécharger le fichier `fasostore-phase1.zip` fourni avec la phase 1. Laissez-le dans **Téléchargements**.
2. Ouvrir <https://github.com/> et se connecter ou créer un compte personnel. Activez la double authentification de GitHub ; conservez les codes de récupération dans un endroit sûr, séparé du téléphone si possible.
3. Dans Chrome, si certains boutons sont cachés, ouvrir le menu ⋮ puis activer **Version pour ordinateur**. Agrandir la page au besoin.

## 2. Créer un dépôt privé

1. Ouvrir <https://github.com/new>.
2. Donner exactement le nom `fasostore` au dépôt et choisir **Private**.
3. Activer **Add a README file**, puis toucher **Create repository**.
4. Dans le dépôt, choisir **Add file → Upload files → choose your files**, puis choisir `fasostore-phase1.zip` dans les téléchargements Android.
5. Toucher **Commit changes**. L'archive est alors enregistrée, mais GitHub ne l'extrait pas automatiquement.

## 3. Ouvrir Codespaces dans le navigateur

1. Sur la page du dépôt, choisir **Code → Codespaces → Create codespace on main**. Patienter jusqu'à l'apparition de l'éditeur web. La première ouverture peut prendre quelques minutes.
2. Ouvrir un terminal dans l'éditeur : menu **Terminal → New Terminal**. Sur petit écran, le menu principal peut être rangé derrière l'icône ≡.
3. Coller les commandes suivantes dans ce terminal, en attendant la fin de chacune. Elles ne s'exécutent **pas** dans une application terminal sur votre téléphone : elles tournent dans le serveur Codespaces.

```bash
cd /workspaces/fasostore
python3 -m zipfile -e fasostore-phase1.zip .
nvm install 24
nvm use 24
node -v
npm -v
```

La commande `node -v` doit commencer par `v24.`. L'extraction remplace le README initial de GitHub par celui du projet et crée les dossiers `apps` et `docs`. La configuration `.devcontainer` servira aux futurs Codespaces créés après l'enregistrement du projet ; pour ce premier Codespace créé avant extraction, `nvm install 24` est nécessaire.

Si `nvm` n'est pas trouvé, le Codespace n'utilise probablement pas l'image GitHub par défaut : arrêtez-vous et communiquez le message d'erreur. Ne copiez aucun secret.

## 4. Installer et vérifier

```bash
npm ci
npm run check
npm audit --audit-level=high
```

Attendre la fin de chaque commande. `npm run check` doit se terminer sans erreur : deux suites de tests, six tests réussis et deux compilations. L'audit peut évoluer lorsque de nouvelles vulnérabilités sont publiées : en cas d'erreur, transmettre le message, sans informations sensibles. Ne pas poursuivre vers la phase 2 en cas d'échec.

## 5. Enregistrer le véritable code sur GitHub

Ces commandes suppriment l'archive du **dernier état du dépôt** et enregistrent à sa place les fichiers extraits. L'archive reste néanmoins dans l'historique Git ; elle ne contient aucun secret dans la livraison d'origine.

```bash
git rm fasostore-phase1.zip
git add -A
git status --short
git commit -m "Phase 1 : socle FasoStore"
git push
```

Avant le commit, `git status --short` ne doit pas afficher de fichier de secrets comme `.env.local`. Les dossiers `node_modules`, `.next` et `dist` sont ignorés. Les contrôles GitHub Actions se lanceront après le `push` si Actions est activé sur le dépôt ; le quota gratuit éventuel dépend de votre compte.

## 6. Lancer et ouvrir FasoStore

```bash
npm run dev
```

Garder ce terminal ouvert. L'API et l'interface se lancent ensemble. Dans le panneau **Ports**, trouver **3000**, puis toucher l'icône **Open in Browser**. Si le port n'apparaît pas, utiliser **Add port** et saisir `3000`. Laisser les ports en visibilité **Private**. Le lien HTTPS généré par GitHub s'ouvre dans un nouvel onglet ; connectez-vous à GitHub si demandé.

Ne tapez pas `localhost:3000` dans Chrome sur le téléphone : `localhost` y désigne votre téléphone, pas le serveur Codespaces. L'API sur le port 4000 n'a pas besoin d'être ouverte publiquement.

Dans FasoStore :

- La carte **API FasoStore** doit afficher **Connectée** après quelques secondes. Touchez son bouton d'actualisation pour retester.
- Utilisez le bouton lune/soleil, puis rechargez la page pour vérifier la mémorisation du thème.
- Les éléments « base de données », « comptes » et « mise en production » doivent être marqués comme prévus : ils ne sont pas simulés.
- En cas de « Indisponible », vérifiez d'abord que la commande `npm run dev` est toujours active et que l'API n'a pas affiché d'erreur ; touchez ensuite l'actualisation.

## 7. Arrêter sans perdre son travail

Dans le terminal, `Ctrl+C` arrête les deux serveurs. Ensuite, sur <https://github.com/codespaces>, utiliser le menu du Codespace puis **Stop codespace** pour arrêter le calcul. Le stockage d'un Codespace arrêté continue à compter dans son quota. Avant de **supprimer** un Codespace, vérifiez que tout changement utile a bien été commité et poussé ; la suppression peut effacer le travail non enregistré sur GitHub.

Codespaces est un espace de développement temporaire, pas l'hébergement final de la plateforme. Consultez la facturation et configurez un budget avant d'utiliser des ressources payantes.
