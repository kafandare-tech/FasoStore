# Déploiement — préparation pour la phase 10

Il n'y a **pas de déploiement commercial réalisé en phase 1**. Codespaces sert à développer et tester ; il n'est pas un serveur de production durable.

## Chemin envisagé, entièrement depuis Android

1. Enregistrer le code sur un dépôt GitHub privé.
2. Dans le navigateur, connecter ce dépôt à un hébergeur tel que Render.
3. Créer un service web Next.js et une API séparée, idéalement en **service privé** sur le même réseau ; utiliser un PostgreSQL managé et un stockage d'objets gérés.
4. Configurer les variables et secrets dans le tableau de bord de l'hébergeur, jamais dans Git. `API_INTERNAL_URL` côté web doit être l'URL réelle du service API, fournie par l'hébergeur ; ne pas utiliser `localhost` entre deux services séparés. Les accès base et stockage restent côté API.
5. Activer domaine/TLS, sauvegardes et alertes ; vérifier les rôles, la restauration, les flux de paiement en sandbox, la sécurité et les performances avant ouverture.

Les commandes de base du socle, depuis la racine du dépôt, seront à adapter aux services réels :

| Service | Compilation | Démarrage |
| --- | --- | --- |
| API | `npm ci && npm run build -w @fasostore/api` | `npm run start -w @fasostore/api` |
| Web | `npm ci && npm run build -w @fasostore/web` | `npm run start -w @fasostore/web` |

Le service doit utiliser Node.js 24 et écouter sur le `PORT` fourni par l'hébergeur. `API_INTERNAL_URL` est obligatoire pour le web en mode production, même si les deux processus tournent sur la même machine. L'API ne doit pas être publiée inutilement ; les webhooks nécessiteront un point d'entrée HTTPS contrôlé.

**Coûts :** comparer les tarifs, limites, pays acceptés et conditions au moment du déploiement ; réseau privé, disponibilité continue, sauvegardes, stockage, domaine, paiements et trafic peuvent être payants. Les offres gratuites de Render ne sont pas prévues pour la production. Le plan Hobby gratuit de Vercel est limité à un usage personnel non commercial : ne pas l'utiliser pour le SaaS commercial. La phase 10 comprendra les instructions complètes adaptées au prestataire effectivement choisi.
