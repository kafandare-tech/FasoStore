import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'FasoStore — Créez. Vendez. Développez.',
  description: 'FasoStore, une plateforme de commerce en ligne pensée pour les entrepreneurs.'
};

const themeScript = `(function(){try{var t=localStorage.getItem('fasostore-theme');document.documentElement.dataset.theme=t==='dark'||t==='light'?t:(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light')}catch(e){document.documentElement.dataset.theme='light'}})();`;

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="fr" suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: themeScript }} /></head>
      <body>{children}</body>
    </html>
  );
}
