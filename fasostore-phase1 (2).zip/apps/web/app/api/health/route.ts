// Browser -> same-origin Next.js route -> server-side API. No API secrets reach the browser.
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
const headers = { 'Cache-Control': 'no-store' };

export async function GET() {
  try {
    const configured = process.env.API_INTERNAL_URL;
    if (!configured && process.env.NODE_ENV === 'production') throw new Error('API non configurée');
    const origin = new URL(configured || 'http://127.0.0.1:4000');
    if (!['http:', 'https:'].includes(origin.protocol) || origin.username || origin.password || origin.search || origin.hash || !['', '/'].includes(origin.pathname)) {
      throw new Error('URL API invalide');
    }
    const response = await fetch(new URL('/healthz', origin), {
      cache: 'no-store', redirect: 'error', signal: AbortSignal.timeout(5000)
    });
    if (!response.ok) throw new Error('API indisponible');
    const body: unknown = await response.json();
    if (!body || typeof body !== 'object' || !('status' in body) || body.status !== 'ok' || !('service' in body) || body.service !== 'fasostore-api') {
      throw new Error('Réponse invalide');
    }
    return Response.json({ status: 'ok', checkedAt: new Date().toISOString() }, { headers });
  } catch {
    // Deliberately hide internal URL, upstream responses, and error details.
    return Response.json({ status: 'unavailable' }, { status: 503, headers });
  }
}
