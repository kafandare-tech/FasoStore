import {
  ArrowDownRight, ArrowRight, Blocks, BookOpen, Check, ChevronRight, CircleHelp,
  ClipboardList, Code2, Database, Globe2, Layers3, LayoutDashboard, LockKeyhole,
  Map, PackageCheck, ShieldCheck, Sparkles, Store, Workflow
} from 'lucide-react';
import { Brand } from '../components/brand';
import { LiveHealth } from '../components/live-health';
import { StoreArt } from '../components/store-art';
import { ThemeToggle } from '../components/theme-toggle';

const nav = [
  { label: 'Vue d’ensemble', href: '#apercu', Icon: LayoutDashboard },
  { label: 'Vérifications', href: '#verification', Icon: ClipboardList },
  { label: 'Architecture', href: '#architecture', Icon: Layers3 },
  { label: 'Feuille de route', href: '#feuille-de-route', Icon: Map }
];

const phases = [
  ['01', 'Architecture et préparation', 'Le socle du projet'],
  ['02', 'Base de données', 'PostgreSQL et isolation'],
  ['03', 'Authentification et sécurité', 'Comptes, sessions et rôles'],
  ['04', 'Administration', 'Pilotage de la plateforme'],
  ['05', 'Boutiques', 'Création et personnalisation'],
  ['06', 'Catalogue', 'Produits, catégories et stocks'],
  ['07', 'Commandes et paiements', 'Ventes et moyens de paiement'],
  ['08', 'Livraisons et notifications', 'Suivi et communication'],
  ['09', 'Abonnements', 'Offres et monétisation'],
  ['10', 'Tests et déploiement', 'Préparation à la production']
];

function Navigation({ mobile = false }: { mobile?: boolean }) {
  return <nav className={mobile ? 'mobile-nav' : 'side-nav'} aria-label="Navigation de la page">
    {!mobile && <span className="nav-heading">ESPACE DE LANCEMENT</span>}
    {nav.map(({ label, href, Icon }, i) => <a className={i === 0 ? 'nav-link nav-active' : 'nav-link'} href={href} key={href}><Icon size={18} strokeWidth={1.8} aria-hidden="true" /><span>{label}</span>{!mobile && i === 0 && <span className="nav-active-dot" />}</a>)}
  </nav>;
}

export default function Home() {
  return (
    <div className="app-shell" id="apercu">
      <aside className="sidebar">
        <Brand />
        <Navigation />
        <div className="sidebar-bottom">
          <div className="side-note">
            <span className="side-note-icon"><Sparkles size={17} /></span>
            <strong>Tout commence ici.</strong>
            <p>Une plateforme ambitieuse, construite une étape à la fois.</p>
            <a href="#feuille-de-route">Voir les étapes <ArrowRight size={15} /></a>
          </div>
          <div className="side-footer"><span className="tiny-dot" /> Projet en construction <span>·</span> v0.1</div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div className="mobile-brand"><Brand /></div>
          <div className="breadcrumb"><span>FASOSTORE</span><ChevronRight size={14} /><strong>Vue d’ensemble</strong></div>
          <div className="top-actions"><span className="phase-pill"><span className="tiny-dot" /> Phase 01 <span className="pill-muted">/ 10</span></span><ThemeToggle /></div>
        </header>
        <Navigation mobile />

        <div className="content">
          <div className="welcome-row">
            <div><div className="eyebrow">VOTRE ESPACE DE LANCEMENT <span>✦</span></div><h1>Bienvenue sur FasoStore<span className="title-period">.</span></h1><p>Une belle idée mérite un bon départ. Construisons la suite ensemble.</p></div>
            <span className="welcome-badge"><span /> FONDATIONS</span>
          </div>

          <section className="hero" aria-labelledby="hero-title">
            <div className="hero-content">
              <div className="hero-kicker"><span>✦</span> L’AVENTURE COMMENCE ICI</div>
              <h2 id="hero-title">Votre commerce<br /><em>mérite de voir plus grand.</em></h2>
              <p>Créez, vendez et développez votre activité en ligne. Chaque grande boutique commence par des fondations solides.</p>
              <div className="hero-actions"><a className="button button-primary" href="#verification">Vérifier les fondations <ArrowRight size={17} /></a><a className="button button-ghost" href="#feuille-de-route">Voir les étapes <ArrowDownRight size={16} /></a></div>
            </div>
            <StoreArt />
            <div className="hero-grain" />
          </section>

          <section className="section" id="verification" aria-labelledby="verification-title">
            <div className="section-head"><div><div className="section-kicker">LES PREMIERS PAS <span>—</span> 01</div><h2 id="verification-title">L’état de vos fondations</h2><p>Ce qui fonctionne aujourd’hui et ce qui sera construit ensuite.</p></div><span className="live-key"><span className="live-pulse" /> ÉTAT DE L’API</span></div>
            <div className="status-grid">
              <LiveHealth />
              <article className="status-card"><div className="status-card-head"><span className="status-icon status-icon-amber"><Database size={19} /></span><span className="card-number">02</span></div><h3>Base de données</h3><p>PostgreSQL et isolation des boutiques.</p><div className="state-label state-planned"><span className="state-dot" /> Prévue · phase 02</div><small className="check-time">Pas encore configurée</small></article>
              <article className="status-card"><div className="status-card-head"><span className="status-icon status-icon-lilac"><LockKeyhole size={19} /></span><span className="card-number">03</span></div><h3>Comptes & sécurité</h3><p>Connexion, sessions et permissions.</p><div className="state-label state-planned"><span className="state-dot" /> Prévue · phase 03</div><small className="check-time">Pas encore disponible</small></article>
              <article className="status-card"><div className="status-card-head"><span className="status-icon status-icon-blue"><Globe2 size={19} /></span><span className="card-number">10</span></div><h3>Mise en production</h3><p>Tests et ouverture de la plateforme.</p><div className="state-label state-planned"><span className="state-dot" /> Prévue · phase 10</div><small className="check-time">Pas encore déployée</small></article>
            </div>
            <p className="health-disclaimer"><CircleHelp size={15} /> La vérification de l’API confirme uniquement que son service répond. Elle ne teste pas la base de données ni la sécurité globale.</p>
          </section>

          <div className="lower-grid">
            <section className="panel architecture-panel" id="architecture" aria-labelledby="architecture-title">
              <div className="panel-top"><div><div className="section-kicker">UNE BASE ÉVOLUTIVE</div><h2 id="architecture-title">Pensé pour grandir</h2><p>Une architecture claire, prête à évoluer étape par étape.</p></div><span className="panel-icon"><Workflow size={19} /></span></div>
              <div className="architecture-list">
                <div className="architecture-item"><span className="arch-icon arch-green"><Blocks size={19} /></span><div><strong>Interface web</strong><small>Next.js, React & TypeScript</small></div><span className="arch-chip done"><Check size={12} /> En place</span></div>
                <div className="arch-connector" />
                <div className="architecture-item"><span className="arch-icon arch-orange"><Code2 size={19} /></span><div><strong>API indépendante</strong><small>Fastify & TypeScript</small></div><span className="arch-chip done"><Check size={12} /> En place</span></div>
                <div className="arch-connector" />
                <div className="architecture-item"><span className="arch-icon arch-purple"><Database size={19} /></span><div><strong>Base de données</strong><small>PostgreSQL · phase 02</small></div><span className="arch-chip planned">À venir</span></div>
              </div>
              <div className="arch-foot"><ShieldCheck size={17} /><span>L’isolation des boutiques et les contrôles d’accès seront implémentés puis testés dans les prochaines phases.</span></div>
            </section>

            <section className="panel next-panel" aria-labelledby="next-title">
              <div className="panel-top"><div><div className="section-kicker">ET ENSUITE ?</div><h2 id="next-title">La suite de l’aventure</h2><p>Un projet solide se construit progressivement.</p></div><span className="panel-icon panel-icon-amber"><Sparkles size={19} /></span></div>
              <div className="next-card"><div className="next-number">02</div><div><div className="next-label">PROCHAINE ÉTAPE</div><h3>Créer la base de données</h3><p>Définir les données du projet et préparer l’isolation entre boutiques.</p></div><Database className="next-card-icon" size={25} /></div>
              <div className="next-tips"><div><span className="tip-icon"><Check size={15}/></span><p><strong>Vérifier cette première phase</strong><small>Interface, API et tests du socle.</small></p></div><div><span className="tip-icon tip-outline"><Store size={15}/></span><p><strong>Avancer à votre rythme</strong><small>Chaque étape sera expliquée pour Android.</small></p></div></div>
              <a className="text-link" href="#feuille-de-route">Consulter toute la feuille de route <ArrowRight size={16} /></a>
            </section>
          </div>

          <section className="section roadmap-section" id="feuille-de-route" aria-labelledby="roadmap-title">
            <div className="section-head"><div><div className="section-kicker">LE CHEMIN À PARCOURIR <span>—</span> 10 ÉTAPES</div><h2 id="roadmap-title">De l’idée à la mise en ligne</h2><p>Une feuille de route transparente, sans fonctionnalités simulées.</p></div><span className="roadmap-badge"><Map size={15} /> 10 phases</span></div>
            <div className="roadmap-grid">{phases.map(([number, title, subtitle], index) => <article className={`roadmap-item ${index === 0 ? 'roadmap-current' : ''}`} key={number}><div className="roadmap-item-top"><span>{number}</span><span className={index === 0 ? 'roadmap-state current' : 'roadmap-state'}>{index === 0 ? 'À valider' : 'À venir'}</span></div><h3>{title}</h3><p>{subtitle}</p></article>)}</div>
          </section>

          <div className="closing-note"><span className="closing-icon"><BookOpen size={19}/></span><p><strong>Ce socle n’est pas encore une boutique opérationnelle.</strong><br />Les comptes, les ventes et les paiements seront développés et vérifiés dans les phases suivantes.</p><PackageCheck size={22} className="closing-end" /></div>
          <footer className="footer"><span>© FasoStore <i>·</i> Créez. Vendez. Développez.</span><span>Fait pour vos ambitions <span className="footer-spark">✦</span></span></footer>
        </div>
      </main>
    </div>
  );
}
