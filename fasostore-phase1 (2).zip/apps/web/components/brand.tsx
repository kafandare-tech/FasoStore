export function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <a className="brand" href="#apercu">
      <span className="brand-mark" aria-hidden="true">
        <svg width="25" height="25" viewBox="0 0 32 32" fill="none">
          <path d="M6.2 12.2 8.4 6h15.2l2.2 6.2M7.7 15.1v9.6c0 .7.5 1.2 1.2 1.2h14.2c.7 0 1.2-.5 1.2-1.2v-9.6M12.4 25.9v-6.6c0-.7.5-1.2 1.2-1.2h4.8c.7 0 1.2.5 1.2 1.2v6.6" stroke="currentColor" strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round"/>
          <path d="M5.7 12.1h20.6v.5a3 3 0 0 1-5.1 2.1 3 3 0 0 1-5.2 0 3 3 0 0 1-5.2 0 3 3 0 0 1-5.1-2.1v-.5Z" fill="currentColor"/>
        </svg>
      </span>
      {!compact && <span className="brand-word">Faso<span>Store</span><small>VOTRE COMMERCE EN LIGNE</small></span>}
    </a>
  );
}
