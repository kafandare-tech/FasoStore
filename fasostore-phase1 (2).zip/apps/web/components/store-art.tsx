/** A symbolic illustration, not live commercial data. */
export function StoreArt() {
  return (
    <div className="art-wrap" aria-hidden="true">
      <div className="art-orbit art-orbit-one" />
      <div className="art-orbit art-orbit-two" />
      <div className="art-spark art-spark-one">✦</div>
      <div className="art-spark art-spark-two">✳</div>
      <div className="art-window">
        <div className="art-window-top"><span /><span /><span /><i /></div>
        <div className="art-window-body">
          <div className="art-awning"><i /><i /><i /><i /><i /></div>
          <div className="art-store">
            <div className="art-store-sign"><span /><span /></div>
            <div className="art-shelf"><div className="art-product art-product-one" /><div className="art-product art-product-two" /><div className="art-product art-product-three" /></div>
            <div className="art-counter" />
          </div>
        </div>
      </div>
      <div className="art-note"><span className="art-note-icon">✦</span><span>Une idée.<strong>Un commerce.</strong></span></div>
      <div className="art-tag"><span>✺</span> Fait pour entreprendre</div>
    </div>
  );
}
