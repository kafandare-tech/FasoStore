'use client';

import { useEffect, useState } from 'react';
import { Moon, Sun } from 'lucide-react';

export function ThemeToggle() {
  const [dark, setDark] = useState(false);
  useEffect(() => { setDark(document.documentElement.dataset.theme === 'dark'); }, []);
  function toggle() {
    const next = !dark;
    setDark(next);
    document.documentElement.dataset.theme = next ? 'dark' : 'light';
    try { localStorage.setItem('fasostore-theme', next ? 'dark' : 'light'); } catch { /* storage is optional */ }
  }
  return (
    <button className="icon-button theme-button" type="button" onClick={toggle} aria-label={dark ? 'Activer le mode clair' : 'Activer le mode sombre'} title={dark ? 'Mode clair' : 'Mode sombre'}>
      {dark ? <Sun size={19} /> : <Moon size={19} />}
    </button>
  );
}
