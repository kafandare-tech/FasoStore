'use client';

import { Activity, RefreshCw } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';

type State = { kind: 'checking' | 'ok' | 'unavailable'; checkedAt?: string };

export function LiveHealth() {
  const [state, setState] = useState<State>({ kind: 'checking' });
  const check = useCallback(async () => {
    setState({ kind: 'checking' });
    try {
      const response = await fetch('/api/health', { cache: 'no-store', signal: AbortSignal.timeout(8000) });
      const body: unknown = await response.json();
      if (!response.ok || !body || typeof body !== 'object' || !('status' in body) || body.status !== 'ok') throw new Error();
      const checkedAt = 'checkedAt' in body && typeof body.checkedAt === 'string' ? body.checkedAt : new Date().toISOString();
      setState({ kind: 'ok', checkedAt });
    } catch {
      setState({ kind: 'unavailable', checkedAt: new Date().toISOString() });
    }
  }, []);
  useEffect(() => { void check(); }, [check]);
  const label = state.kind === 'checking' ? 'Vérification…' : state.kind === 'ok' ? 'Connectée' : 'Indisponible';
  const time = state.checkedAt ? new Intl.DateTimeFormat('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(new Date(state.checkedAt)) : '';
  return (
    <article className="status-card status-api">
      <div className="status-card-head">
        <span className="status-icon status-icon-green"><Activity size={19} aria-hidden="true" /></span>
        <button className="refresh-button" onClick={() => void check()} disabled={state.kind === 'checking'} type="button" aria-label="Actualiser l’état de l’API" title="Actualiser l’état de l’API">
          <RefreshCw size={16} className={state.kind === 'checking' ? 'spinning' : ''} />
        </button>
      </div>
      <h3>API FasoStore</h3>
      <p>Communication avec le serveur.</p>
      <div className={`state-label state-${state.kind}`} role="status" aria-live="polite"><span className="state-dot" />{label}</div>
      <small className="check-time">{time ? `Vérifiée à ${time}` : 'Vérification en cours'}</small>
    </article>
  );
}
