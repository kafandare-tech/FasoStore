import { afterEach, describe, expect, it, vi } from 'vitest';
import { GET } from '../app/api/health/route';

const originalUrl = process.env.API_INTERNAL_URL;
afterEach(() => {
  vi.unstubAllGlobals();
  if (originalUrl === undefined) delete process.env.API_INTERNAL_URL;
  else process.env.API_INTERNAL_URL = originalUrl;
});

describe('Relais de santé côté serveur', () => {
  it('ne renvoie que les données publiques nécessaires', async () => {
    process.env.API_INTERNAL_URL = 'http://127.0.0.1:4000';
    const mockFetch = vi.fn().mockResolvedValue(new Response(JSON.stringify({ service: 'fasostore-api', status: 'ok', secret: 'secret-interne' }), { status: 200 }));
    vi.stubGlobal('fetch', mockFetch);
    const response = await GET();
    const body = await response.json();
    expect(response.status).toBe(200);
    expect(body.status).toBe('ok');
    expect(typeof body.checkedAt).toBe('string');
    expect(JSON.stringify(body)).not.toContain('secret-interne');
    expect(response.headers.get('cache-control')).toBe('no-store');
    expect(String(mockFetch.mock.calls[0][0])).toBe('http://127.0.0.1:4000/healthz');
  });
  it('retourne 503 et aucun détail interne si l’API est inaccessible', async () => {
    process.env.API_INTERNAL_URL = 'http://127.0.0.1:4000';
    vi.stubGlobal('fetch', vi.fn().mockRejectedValue(new Error('détail privé')));
    const response = await GET();
    expect(response.status).toBe(503);
    expect(await response.json()).toEqual({ status: 'unavailable' });
  });
  it('rejette une réponse incohérente et une URL de configuration invalide', async () => {
    process.env.API_INTERNAL_URL = 'http://127.0.0.1:4000';
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response(JSON.stringify({ status: 'ok' }))));
    expect((await GET()).status).toBe(503);
    process.env.API_INTERNAL_URL = 'file:///etc/passwd';
    expect((await GET()).status).toBe(503);
  });
});
