import { afterEach, describe, expect, it } from 'vitest';
import { createApp } from '../src/app.js';

const apps: ReturnType<typeof createApp>[] = [];
const newApp = () => { const app = createApp({ logger: false }); apps.push(app); return app; };
afterEach(async () => { await Promise.all(apps.splice(0).map((app) => app.close())); });

describe('API FasoStore - phase 1', () => {
  it('renvoie un état réel, non mis en cache, avec des en-têtes de sécurité', async () => {
    const response = await newApp().inject({ method: 'GET', url: '/healthz' });
    expect(response.statusCode).toBe(200);
    expect(response.json()).toEqual({ service: 'fasostore-api', status: 'ok', phase: 1 });
    expect(response.headers['cache-control']).toBe('no-store');
    expect(response.headers['x-content-type-options']).toBe('nosniff');
    expect(response.headers['x-powered-by']).toBeUndefined();
  });

  it('ne révèle aucune trace sur une route absente', async () => {
    const response = await newApp().inject({ method: 'GET', url: '/inconnue' });
    expect(response.statusCode).toBe(404);
    expect(response.json()).toEqual({ error: 'Ressource introuvable' });
  });

  it('limite les requêtes répétées sur cette instance', async () => {
    const app = newApp();
    let statusCode = 0;
    for (let i = 0; i < 121; i++) {
      statusCode = (await app.inject({ method: 'GET', url: '/healthz' })).statusCode;
    }
    expect(statusCode).toBe(429);
  });
});
