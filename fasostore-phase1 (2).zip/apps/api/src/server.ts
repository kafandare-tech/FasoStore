import { z } from 'zod';
import { createApp } from './app.js';

const port = z.coerce.number().int().min(1).max(65535).default(4000).parse(process.env.PORT);
const host = process.env.HOST || '0.0.0.0';
const app = createApp();

try {
  await app.listen({ port, host });
} catch {
  app.log.error('Démarrage impossible');
  process.exit(1);
}

for (const signal of ['SIGINT', 'SIGTERM'] as const) {
  process.once(signal, () => {
    void app.close().then(() => process.exit(0)).catch(() => process.exit(1));
  });
}
