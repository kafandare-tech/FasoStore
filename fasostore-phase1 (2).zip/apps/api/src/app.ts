import Fastify from 'fastify';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import { randomUUID } from 'node:crypto';

/** An isolated API instance lets tests exercise the same routes without opening a port. */
export function createApp(options: { logger?: boolean } = {}) {
  const app = Fastify({
    logger: options.logger === false ? false : {
      level: 'info',
      redact: {
        paths: ['req.headers.authorization', 'req.headers.cookie', 'res.headers.set-cookie'],
        censor: '[REDACTED]'
      }
    },
    // Do not trust client-supplied forwarded IPs. Production proxy policy is a later task.
    trustProxy: false,
    bodyLimit: 1024 * 1024,
    genReqId: () => randomUUID()
  });

  app.register(helmet);
  // Phase 1: per-process abuse protection for the health route only.
  // A shared limiter and a trusted-proxy policy are mandatory before sensitive routes.
  app.register(rateLimit, { global: true, max: 120, timeWindow: '1 minute' });

  // Register routes after the limiter's onRoute hook is installed.
  app.after(() => {
    app.get('/healthz', async (_request, reply) => {
      reply.header('Cache-Control', 'no-store');
      return { service: 'fasostore-api', status: 'ok', phase: 1 };
    });
  });

  app.setNotFoundHandler(async (_request, reply) => {
    return reply.code(404).send({ error: 'Ressource introuvable' });
  });

  app.setErrorHandler(async (error, request, reply) => {
    const code = error && typeof error === 'object' && 'statusCode' in error && typeof error.statusCode === 'number' ? error.statusCode : 500;
    // Never return stack traces, request bodies or raw exception messages to callers.
    if (code >= 500) request.log.error({ requestId: request.id }, 'Erreur interne');
    const safeCode = code >= 400 && code <= 599 ? code : 500;
    return reply.code(safeCode).send({
      error: safeCode === 429 ? 'Trop de requêtes' : safeCode < 500 ? 'Requête invalide' : 'Erreur interne'
    });
  });

  return app;
}
