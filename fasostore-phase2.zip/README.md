# FasoStore — phases 1 et 2

**Créez. Vendez. Développez votre commerce en ligne.**

Ce projet est le socle réellement exécutable de FasoStore, pas encore une boutique commerciale. La phase 1 est validée et l'aperçu public existe. La phase 2 ajoute le code et les migrations de PostgreSQL ; la base cloud doit encore être créée, connectée et vérifiée par le propriétaire.

## Fonctionnalités présentes dans ce code

- Site français responsive, navigation et thème clair/sombre, avec Next.js, React et TypeScript.
- API Fastify séparée logiquement, avec `/healthz` et relais web `/api/health`, conservés depuis la phase 1.
- Migration PostgreSQL versionnée : `tenants`, `users`, `memberships`, `store_settings` et version de schéma. Aucune boutique ni aucun utilisateur réel n'est créé.
- RLS forcée sur les trois tables liées aux boutiques, rôle applicatif SQL limité, transactions avec contexte local, TLS avec vérification du certificat et du nom du serveur.
- Nouvelle vérification réelle `/api/database-health` et carte Base de données. Le statut « Connectée » vérifie la connexion et une partie de la configuration ; ce n'est pas un audit complet ni une preuve d'autorisation des utilisateurs.
- Tests unitaires et tests d'intégration PostgreSQL séparés. Le workflow GitHub Actions est présent dans l'archive ; il ne s'exécute pas tant que le dossier `.github/workflows` reste uniquement dans le ZIP du dépôt.

**Pas encore disponibles :** inscription, connexion, 2FA, sessions, contrôle des droits des personnes, gestion des boutiques, produits, commandes, paiements, livraisons, abonnements et sauvegardes opérationnelles. Ne pas y saisir de vraies données clients ni accepter de paiement.

**Important :** la RLS ne remplace pas l'authentification. Le rôle serveur peut définir un contexte de boutique ; une future route devra vérifier côté serveur l'identité, l'appartenance et les permissions. Aucun accès métier multi-boutique n'est exposé dans cette phase.

## Fichiers

```text
apps/web/                             Interface Next.js et relais serveur
apps/api/                             API Fastify, PostgreSQL et tests
database/migrations/001_fondations.sql  Migration initiale à exécuter une fois
database/tests/002_verifier_isolation.sql Test temporaire d'isolation A/B
database/tests/003_controler_installation.sql Contrôles lisibles
docs/GUIDE_ANDROID_PHASE2.md           Mode d'emploi sans terminal
docs/ARCHITECTURE.md                  Architecture et limites
docs/SECURITE.md                      Mesures et étapes de sécurité futures
docs/DEPLOIEMENT.md                   Render de test et déploiement futur
package-lock.json                     Versions verrouillées
```

Les fichiers SQL ne contiennent aucun mot de passe. L'archive est conçue pour être déposée dans le dépôt GitHub public utilisé pour l'aperçu, mais **aucun secret ne doit y être ajouté**.

## Tests de développement

Dans un environnement de développement Node.js 24 : `npm ci`, `npm run check`, `npm audit --audit-level=high`. `npm run check` vérifie TypeScript, exécute les tests unitaires et compile. Les tests PostgreSQL d'intégration sont volontairement ignorés sans base locale de test ; ils ont été exécutés séparément sur PostgreSQL 17 avec un rôle administrateur et un vrai rôle applicatif limité. Voir [la documentation](docs/PHASE2_BASE.md).

Sur Android, le parcours normal utilise Chrome, GitHub, Neon et Render, **sans terminal local** : [Guide Android phase 2](docs/GUIDE_ANDROID_PHASE2.md).

Les offres gratuites et les tests ponctuels ne garantissent pas disponibilité, sauvegardes ou sécurité commerciale. Une validation indépendante et des restaurations testées sont nécessaires avant production.
