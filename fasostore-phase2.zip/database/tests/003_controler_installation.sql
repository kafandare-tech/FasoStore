-- Contrôle lisible de la configuration. Aucun mot de passe n'est affiché.
-- À exécuter après 001_fondations.sql dans la base de test dédiée.
SELECT
  (SELECT count(*) = 1 FROM fasostore.schema_migrations WHERE version = '001_fondations') AS migration_ok,
  (SELECT coalesce(bool_and(rolcanlogin AND NOT rolsuper AND NOT rolbypassrls
    AND NOT rolcreaterole AND NOT rolcreatedb AND NOT rolreplication AND NOT rolinherit), false)
    FROM pg_catalog.pg_roles WHERE rolname = 'fasostore_app') AS role_limite,
  NOT EXISTS (
    SELECT 1 FROM pg_catalog.pg_auth_members m JOIN pg_catalog.pg_roles r ON r.oid = m.member
    WHERE r.rolname = 'fasostore_app'
  ) AS aucune_appartenance,
  COALESCE((SELECT NOT pg_has_role('fasostore_app', r.oid, 'MEMBER')
    FROM pg_catalog.pg_roles r WHERE r.rolname = 'neon_superuser'), true) AS sans_neon_superuser,
  NOT has_table_privilege('fasostore_app', 'fasostore.users',
    'SELECT, INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER') AS users_inaccessibles,
  (SELECT count(*) = 3 FROM pg_catalog.pg_class c
    JOIN pg_catalog.pg_namespace s ON s.oid = c.relnamespace
    WHERE s.nspname = 'fasostore' AND c.relname IN ('tenants','memberships','store_settings')
      AND c.relkind = 'r' AND c.relrowsecurity AND c.relforcerowsecurity
      AND NOT pg_has_role('fasostore_app', c.relowner, 'MEMBER')
      AND NOT has_table_privilege('fasostore_app', c.oid, 'TRUNCATE')) AS rls_et_proprietaire_ok;
