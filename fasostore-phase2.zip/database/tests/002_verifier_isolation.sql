-- Test de RLS pour la base de TEST FasoStore uniquement.
-- À exécuter dans Neon SQL Editor après 001_fondations.sql, avec le même
-- administrateur qui a créé les objets. Un seul bloc, aucune donnée conservée.
-- Le résultat attendu est une exécution réussie (et une notice si affichée).
DO $test$
DECLARE
  admin_role name := current_user;
  a uuid := '11111111-1111-4111-8111-111111111111';
  b uuid := '22222222-2222-4222-8222-222222222222';
  user_a uuid := 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
  user_b uuid := 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb';
  n integer;
BEGIN
  -- Le sous-bloc est annulé intentionnellement à la fin, même en cas de succès.
  BEGIN
    -- Le créateur possède normalement ADMIN OPTION mais pas SET sur ce rôle.
    -- L'autorisation est uniquement temporaire et disparaît avec le sous-bloc.
    EXECUTE format('GRANT fasostore_app TO %I WITH SET TRUE', admin_role);
    -- L'administrateur propriétaire peut lui-même être soumis à FORCE RLS.
    -- Désactiver seulement dans cette sous-transaction les trois tables de test,
    -- insérer les fixtures, puis réactiver avant d'emprunter le rôle applicatif.
    -- Les verrous DDL et l'annulation finale empêchent toute modification durable.
    ALTER TABLE fasostore.tenants DISABLE ROW LEVEL SECURITY;
    ALTER TABLE fasostore.memberships DISABLE ROW LEVEL SECURITY;
    ALTER TABLE fasostore.store_settings DISABLE ROW LEVEL SECURITY;
    INSERT INTO fasostore.tenants(id, name, slug) VALUES
      (a, 'TEST TEMPORAIRE A', 'fasostore-test-temporaire-a'),
      (b, 'TEST TEMPORAIRE B', 'fasostore-test-temporaire-b');
    INSERT INTO fasostore.users(id, email) VALUES
      (user_a, 'test-temporaire-a@exemple.invalid'),
      (user_b, 'test-temporaire-b@exemple.invalid');
    INSERT INTO fasostore.memberships(tenant_id, user_id, member_role) VALUES
      (a, user_a, 'owner'), (b, user_b, 'owner');
    INSERT INTO fasostore.store_settings(tenant_id, store_title) VALUES
      (a, 'TEST TEMPORAIRE A'), (b, 'TEST TEMPORAIRE B');
    ALTER TABLE fasostore.tenants ENABLE ROW LEVEL SECURITY;
    ALTER TABLE fasostore.memberships ENABLE ROW LEVEL SECURITY;
    ALTER TABLE fasostore.store_settings ENABLE ROW LEVEL SECURITY;

    SET LOCAL ROLE fasostore_app;
    IF current_user <> 'fasostore_app' OR NOT row_security_active('fasostore.tenants') THEN
      RAISE EXCEPTION 'Le test ne s’exécute pas avec le rôle applicatif protégé.';
    END IF;
    PERFORM set_config('fasostore.tenant_id', '', true);
    IF EXISTS (SELECT 1 FROM fasostore.tenants) OR EXISTS (SELECT 1 FROM fasostore.memberships)
      OR EXISTS (SELECT 1 FROM fasostore.store_settings) THEN
      RAISE EXCEPTION 'RLS refuse par défaut : test échoué.';
    END IF;
    PERFORM set_config('fasostore.tenant_id', a::text, true);
    SELECT count(*) INTO n FROM fasostore.tenants WHERE id = a;
    IF n <> 1 OR EXISTS (SELECT 1 FROM fasostore.tenants WHERE id = b)
      OR EXISTS (SELECT 1 FROM fasostore.memberships WHERE tenant_id = b)
      OR NOT EXISTS (SELECT 1 FROM fasostore.memberships WHERE tenant_id = a AND user_id = user_a)
      OR EXISTS (SELECT 1 FROM fasostore.store_settings WHERE tenant_id = b) THEN
      RAISE EXCEPTION 'Lecture croisée A/B : test échoué.';
    END IF;
    UPDATE fasostore.store_settings SET store_title = 'INTERDIT' WHERE tenant_id = b;
    GET DIAGNOSTICS n = ROW_COUNT;
    IF n <> 0 THEN RAISE EXCEPTION 'Modification croisée A/B : test échoué.'; END IF;
    BEGIN
      INSERT INTO fasostore.store_settings(tenant_id, store_title) VALUES (b, 'INTERDIT');
      RAISE EXCEPTION 'Insertion croisée A/B acceptée : test échoué.';
    EXCEPTION WHEN insufficient_privilege THEN
      NULL; -- l'échec est attendu
    END;
    PERFORM set_config('fasostore.tenant_id', b::text, true);
    SELECT count(*) INTO n FROM fasostore.tenants WHERE id = b;
    IF n <> 1 OR EXISTS (SELECT 1 FROM fasostore.tenants WHERE id = a)
      OR EXISTS (SELECT 1 FROM fasostore.memberships WHERE tenant_id = a)
      OR NOT EXISTS (SELECT 1 FROM fasostore.memberships WHERE tenant_id = b AND user_id = user_b) THEN
      RAISE EXCEPTION 'Lecture croisée B/A : test échoué.';
    END IF;
    -- Déclencher le rollback de toutes les données et du GRANT temporaires.
    RAISE EXCEPTION USING ERRCODE = 'ZFS01', MESSAGE = 'TEST_TERMINE_ANNULER';
  EXCEPTION WHEN SQLSTATE 'ZFS01' THEN
    RAISE NOTICE 'TEST RLS RÉUSSI : données et droit temporaires annulés.';
  END;
END
$test$;
