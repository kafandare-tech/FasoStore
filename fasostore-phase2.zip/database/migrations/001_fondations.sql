-- FasoStore / phase 2 : UNIQUEMENT dans une base PostgreSQL neuve dédiée aux tests.
-- Administrateur distinct du rôle applicatif. Exécuter UNE FOIS, en entier.
-- Aucune donnée réelle, aucun mot de passe ni aucune clé dans ce fichier.
-- Un mot de passe initial aléatoire est créé côté PostgreSQL et n'est pas affiché.
-- Sur Neon, réinitialiser ensuite ce rôle dans Roles avant la connexion Render.
-- Un seul bloc SQL : tous les changements réussissent ou sont annulés ensemble.
DO $migration$
DECLARE
  initial_secret text;
BEGIN
  -- Refuser une collision au lieu de modifier silencieusement un rôle existant.
  IF EXISTS (SELECT 1 FROM pg_catalog.pg_roles WHERE rolname = 'fasostore_app') THEN
    RAISE EXCEPTION 'Le rôle fasostore_app existe déjà : ne pas continuer automatiquement.';
  END IF;
  -- Deux UUID v4 indépendants : 244 bits aléatoires au total, sans secret fixe.
  initial_secret := replace(gen_random_uuid()::text, '-', '') || replace(gen_random_uuid()::text, '-', '');
  BEGIN
    EXECUTE format(
      'CREATE ROLE fasostore_app LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOREPLICATION NOBYPASSRLS NOINHERIT PASSWORD %L',
      initial_secret
    );
  EXCEPTION WHEN OTHERS THEN
    -- Ne pas renvoyer la requête dynamique ou le secret au client.
    RAISE EXCEPTION 'Création du rôle impossible (code SQL %).', SQLSTATE;
  END;

-- PostgreSQL < 15 : supprimer le droit CREATE par défaut sur le schéma public.
-- À faire seulement dans une base dédiée à FasoStore.
REVOKE CREATE ON SCHEMA public FROM PUBLIC;
CREATE SCHEMA fasostore;
REVOKE ALL ON SCHEMA fasostore FROM PUBLIC;
GRANT USAGE ON SCHEMA fasostore TO fasostore_app;
EXECUTE format('GRANT CONNECT ON DATABASE %I TO fasostore_app', current_database());

CREATE TABLE fasostore.schema_migrations (
  version text PRIMARY KEY,
  applied_at timestamptz NOT NULL DEFAULT now()
);

-- Une boutique = un tenant. Aucun enregistrement n'est créé par cette migration.
CREATE TABLE fasostore.tenants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL CHECK (length(btrim(name)) BETWEEN 1 AND 120),
  slug text NOT NULL UNIQUE CHECK (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$' AND length(slug) <= 80),
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'suspended')),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Identités globales : aucun accès applicatif en phase 2. Les sessions,
-- mots de passe et flux d'authentification seront conçus en phase 3.
CREATE TABLE fasostore.users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL CHECK (length(email) BETWEEN 3 AND 254),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX users_email_lower_unique ON fasostore.users (lower(email));

CREATE TABLE fasostore.memberships (
  tenant_id uuid NOT NULL REFERENCES fasostore.tenants(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES fasostore.users(id) ON DELETE RESTRICT,
  member_role text NOT NULL CHECK (member_role IN ('owner', 'manager', 'staff')),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, user_id)
);
CREATE INDEX memberships_user_id_idx ON fasostore.memberships (user_id, tenant_id);

CREATE TABLE fasostore.store_settings (
  tenant_id uuid PRIMARY KEY REFERENCES fasostore.tenants(id) ON DELETE CASCADE,
  store_title text NOT NULL CHECK (length(btrim(store_title)) BETWEEN 1 AND 120),
  currency char(3) NOT NULL DEFAULT 'XOF' CHECK (currency ~ '^[A-Z]{3}$'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE fasostore.tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE fasostore.tenants FORCE ROW LEVEL SECURITY;
ALTER TABLE fasostore.memberships ENABLE ROW LEVEL SECURITY;
ALTER TABLE fasostore.memberships FORCE ROW LEVEL SECURITY;
ALTER TABLE fasostore.store_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE fasostore.store_settings FORCE ROW LEVEL SECURITY;

-- La valeur est posée seulement pour la transaction de l'API, après une future
-- vérification serveur de l'identité ET de l'appartenance. Jamais depuis un
-- en-tête ou identifiant client considéré comme autorisation.
CREATE POLICY tenant_select ON fasostore.tenants FOR SELECT TO fasostore_app
  USING (id = nullif(current_setting('fasostore.tenant_id', true), '')::uuid);
CREATE POLICY membership_select ON fasostore.memberships FOR SELECT TO fasostore_app
  USING (tenant_id = nullif(current_setting('fasostore.tenant_id', true), '')::uuid);
CREATE POLICY settings_isolation ON fasostore.store_settings FOR ALL TO fasostore_app
  USING (tenant_id = nullif(current_setting('fasostore.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = nullif(current_setting('fasostore.tenant_id', true), '')::uuid);

-- Pas de droits PUBLIC ; l'utilisateur applicatif n'est propriétaire d'aucune
-- table, n'a pas accès à users et ne peut jamais TRUNCATE les tables protégées.
REVOKE ALL ON ALL TABLES IN SCHEMA fasostore FROM PUBLIC;
GRANT SELECT ON fasostore.schema_migrations TO fasostore_app;
GRANT SELECT ON fasostore.tenants, fasostore.memberships TO fasostore_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON fasostore.store_settings TO fasostore_app;
INSERT INTO fasostore.schema_migrations(version) VALUES ('001_fondations');
END
$migration$;
