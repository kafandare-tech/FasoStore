# FasoStore — phase 2 : guide Android sans terminal

**But :** connecter une base PostgreSQL de test à l'aperçu FasoStore déjà en ligne. Tout se fait dans Chrome sur Android. Aucun ordinateur ni terminal local n'est nécessaire. L'application ne sera pas encore une boutique opérationnelle.

## Sécurité avant de commencer

- Cette base est réservée aux **essais** : n'y saisissez pas de données de clients ou de mots de passe personnels.
- Les mots de passe Neon et Render, clés, codes de récupération, URL de connexion complètes et captures où ils apparaissent sont **privés**. Ne les envoyez ni dans le chat ni dans GitHub. Activez la double authentification de vos comptes.
- Le dépôt GitHub actuel est public. Les archives livrées ne contiennent pas de secrets ; ne les modifiez pas pour en ajouter.
- En cas de difficulté, arrêtez-vous et demandez de l'aide avec une capture **masquant les secrets**. Ne supprimez aucune base et ne relancez pas aveuglément les scripts.

Les intitulés de Neon/Render peuvent évoluer ; sur petit écran, Chrome → **⋮ → Version pour ordinateur** peut aider. Des étapes peuvent être réalisées avec l'accompagnement de l'assistant ; il ne peut pas se connecter à votre place.

## 1. Créer le projet PostgreSQL sur Neon

1. Ouvrir <https://console.neon.tech/> dans Chrome. Créer un compte ou se connecter avec votre propre compte.
2. Choisir l'offre **Free** si elle est proposée et si ses conditions actuelles vous conviennent ; elle sert aux essais et comporte des limites.
3. Choisir **New Project** / **Create project**, et saisir `FasoStore-test`.
4. Dans **Postgres database**, choisir **PostgreSQL 17** si proposé, version utilisée pour les tests locaux. Garder la base par défaut `neondb`.
5. Choisir une région aussi proche que possible du service Render ; **Europe (Frankfurt)** est un exemple si votre service est en Europe. Les régions disponibles et les tarifs peuvent évoluer.
6. Valider **Create project**. Attendre le tableau de bord. Noter la branche affichée (`production` ou `main`) et la base `neondb`, sans partager les identifiants affichés dans Connect.

Les étapes suivantes ne concernent que ce **nouveau** projet de test, pas une base préexistante contenant des données.

## 2. Créer les fondations et le rôle limité

1. Dans le projet Neon, ouvrir **Postgres database → SQL Editor**.
2. Sélectionner la branche du projet et la base `neondb`. L'éditeur doit agir avec le rôle administrateur par défaut du projet. Ce rôle admin sert uniquement à la migration ; ne l'utilisez jamais comme compte de l'application.
3. Ouvrir le fichier complet `database/migrations/001_fondations.sql` fourni avec FasoStore. Le sélectionner et le copier **en entier**, du premier commentaire jusqu'à `$migration$;`.
4. Coller le texte dans une nouvelle requête de l'éditeur, sans modification ; toucher **Run** **une seule fois**. Ce fichier ne contient aucun secret, et ne crée aucune vraie boutique.
5. Attendre un message de réussite. S'il y a une erreur, **arrêter** et conserver une capture du message sans identifiants. Ne pas relancer et ne pas créer le rôle depuis le bouton « Add role ».

Le script crée par SQL `fasostore_app` avec des privilèges limités et un mot de passe initial aléatoire non affiché. Sur un projet Neon, les rôles créés directement depuis l'interface sont des rôles à privilèges élevés : **ne remplacez pas ce rôle SQL par un rôle créé via Add role**.

## 3. Vérifier la configuration et l'isolation

1. Dans une **nouvelle** requête SQL Editor de la même base, copier en entier le fichier `database/tests/003_controler_installation.sql`, puis toucher **Run**. Les six colonnes doivent indiquer `true` (ou `t`). Cette requête n'affiche pas de mot de passe.
2. Dans une autre nouvelle requête, copier en entier le fichier `database/tests/002_verifier_isolation.sql`, puis toucher **Run**. Le résultat attendu est une exécution sans erreur. Si les notifications SQL sont affichées, le message indique « TEST RLS RÉUSSI ». Les boutiques de test et les droits temporaires sont annulés automatiquement ; ils ne sont pas conservés.
3. En cas de `false`, d'erreur ou de doute, s'arrêter. Ne pas déclarer la phase validée. Une capture du résultat **sans mot de passe** peut être partagée pour aider au diagnostic.

Ce test exécute les requêtes avec `SET LOCAL ROLE` depuis l'administrateur ; la connexion réelle avec le mot de passe du rôle limité sera également vérifiée à l'étape 7. Les tests ne remplacent pas les futures vérifications des autorisations des utilisateurs.

## 4. Obtenir les paramètres privés de l'application

1. Dans Neon, ouvrir la branche utilisée, puis **Postgres database → Roles**.
2. Repérer `fasostore_app` créé par le script. Dans son menu, toucher **Reset password**, confirmer et copier le nouveau mot de passe dans un gestionnaire privé.
3. Si le rôle n'apparaît pas ou si la réinitialisation n'est pas disponible ou échoue, **arrêtez-vous** et demandez de l'aide. N'utilisez pas `neondb_owner` à la place.
4. Toucher **Connect**, sélectionner la même branche, la base `neondb` et, si possible, le rôle `fasostore_app`. Activer **Connection pooling** pour le trafic de l'application.
5. Dans le sélecteur de format, choisir **Parameters only / Parameters**. Trois valeurs seront nécessaires dans Render :
   - `PGHOST` → la valeur de `FASO_DB_HOST` ; c'est un nom comme `ep-…-pooler.…neon.tech`, **sans** `https://`, sans port, sans guillemets.
   - `PGDATABASE` → la valeur de `FASO_DB_NAME`, généralement `neondb`, sans guillemets.
   - Le mot de passe de `fasostore_app` réinitialisé à l'étape 2 → `FASO_DB_PASSWORD`, sans guillemets.

Ne copiez pas la chaîne de connexion complète dans le chat et ne prenez pas de capture de l'écran où le mot de passe est visible. Gardez ces valeurs pour les champs privés Render, pas pour GitHub.

## 5. Déposer l'archive phase 2 dans GitHub

1. Télécharger l'archive `fasostore-phase2.zip` fournie par l'assistant sur le téléphone.
2. Dans Chrome, ouvrir <https://github.com/kafandare-tech/FasoStore/upload/main>. Se connecter si demandé.
3. Choisir **Choose your files**, puis l'archive dans **Téléchargements**. Toucher **Commit changes**.
4. Vérifier le **nom exact** affiché dans le dépôt. Android peut ajouter ` (1)` ou un autre suffixe à un téléchargement. Ne supprimez pas `fasostore-phase1 (2).zip` : elle permet de revenir à la phase 1.

Un déploiement automatique avec l'ancienne commande peut encore réinstaller la phase 1 : c'est normal tant que la commande n'a pas été changée.

## 6. Modifier Render et ajouter les trois variables

1. Dans <https://dashboard.render.com/>, ouvrir le service Web FasoStore existant, **pas un nouveau service**.
2. Dans **Settings**, remplacer la **Build Command** par la commande ci-dessous **si le fichier GitHub s'appelle exactement** `fasostore-phase2.zip` :

```bash
unzip -oq "fasostore-phase2.zip" && npm ci --include=dev && npm run check && npm audit --audit-level=high
```

Si le nom GitHub comporte ` (1)`, adapter exactement ce nom entre les guillemets. Garder la **Start Command** déjà validée :

```bash
API_INTERNAL_URL=http://127.0.0.1:4000 ./node_modules/.bin/concurrently --kill-others "PORT=4000 HOST=127.0.0.1 npm run start -w @fasostore/api" "npm run start -w @fasostore/web"
```

Ces lignes sont à coller dans les champs Render, **pas** dans un terminal sur le téléphone. Ne collez aucun mot de passe dans ces commandes.

3. Ouvrir **Environment → Add Environment Variable** et ajouter séparément les clés ci-dessous avec leurs valeurs privées obtenues à l'étape 4. Ne retirez pas les variables déjà présentes.

| Clé Render | Valeur |
| --- | --- |
| `FASO_DB_HOST` | `PGHOST` poolé de Neon, seulement le nom d'hôte |
| `FASO_DB_NAME` | `PGDATABASE` de Neon, généralement `neondb` |
| `FASO_DB_PASSWORD` | Mot de passe du rôle **fasostore_app** |

4. Choisir **Save, rebuild, and deploy** si nécessaire afin que le code et les variables soient pris en compte ; attendre **Deploy succeeded / Live**. Si Render a déjà reconstruit le bon ZIP, l'option **Save and deploy** suffit pour appliquer seulement de nouvelles variables. Ne partagez pas les valeurs de la page Environment.

## 7. Vérifier avant de valider

1. Ouvrir <https://fasostore.onrender.com/>. La carte **API FasoStore** doit indiquer « Connectée » ; **Base de données** doit indiquer « Connectée » après la vérification.
2. Ouvrir <https://fasostore.onrender.com/api/database-health>. Le résultat doit contenir `"status":"ok"` sans mot de passe ni adresse interne.
3. Tester les boutons d'actualisation et le thème clair/sombre. Confirmer que les comptes sont toujours marqués à venir.
4. Confirmer aussi les six `true` du contrôle SQL et le succès du test d'isolation A/B. Si tout est correct, annoncer « phase 2 validée » ; sinon s'arrêter pour diagnostiquer.

La carte connectée vérifie la connexion et plusieurs réglages, pas l'ensemble de la sécurité ni les autorisations des personnes. La phase 3 reste indispensable avant toute donnée réelle.

## En cas de problème ou pour revenir à la phase 1

- **Non configurée** : vérifier la présence des trois clés dans Environment. **Indisponible** : vérifier que la migration et les tests ont réussi, l'hôte, la base, le mot de passe et la branche, sans publier ces valeurs. Attendre la sortie de veille éventuelle puis actualiser.
- Si le déploiement phase 2 échoue, Render conserve normalement la dernière version déployée avec succès ; contrôler le statut plutôt que de supposer. Pour revenir volontairement à la phase 1, remettre dans **Build Command** le nom de l'archive réellement présente :

```bash
unzip -oq "fasostore-phase1 (2).zip" && npm ci --include=dev && npm run check && npm audit --audit-level=high
```

Puis lancer **Manual Deploy → Clear build cache & deploy**, ou utiliser le retour arrière disponible dans Render. Ne supprimez pas la base ni aucune archive. En cas de secret partagé, le réinitialiser immédiatement auprès du fournisseur et mettre à jour Render ; supprimer seulement un message ne suffit pas.

## Références fournisseurs

- Neon : [création de projet](https://neon.com/docs/manage/projects), [rôles](https://neon.com/docs/manage/roles), [SQL Editor](https://neon.com/docs/get-started/query-with-neon-sql-editor), [pool de connexions](https://neon.com/docs/connect/connection-pooling).
- Render : [variables d'environnement et options de déploiement](https://render.com/docs/configure-environment-variables), [limites de l'offre gratuite](https://render.com/docs/free).
