# FasoStore — architecture et isolation

## 1. État du code : phases 1 et 2

```text
Navigateur Android / web (HTTPS, mêmes origines)
       │
       ▼
Next.js : site + /api/health + /api/database-health
       │ appel serveur vers l'API ; pas de secret dans le navigateur
       ▼
Fastify : /healthz + /healthz/database
       │ rôle PostgreSQL fasostore_app ; TLS avec certificat et nom vérifiés
       ▼
PostgreSQL : schéma fasostore + migration 001 + politiques RLS
```

L'interface et l'API sont des applications séparées dans le monorepo. Pour l'aperçu Render gratuit, elles tournent dans **un même service** sous deux processus : l'API écoute seulement sur l'interface locale du serveur. Elles ne sont donc pas encore isolées en deux services d'hébergement distincts et partagent les variables du service. Un déploiement commercial devra séparer services, secrets et réseau.

La phase 2 prépare le code et les scripts ; la base Neon de l'utilisateur et la connexion Render doivent être créées et contrôlées séparément. Une carte « Connectée » teste seulement la disponibilité et certains paramètres, pas la sécurité complète.

## 2. Modèle et rôle des accès

- `tenants` représente les boutiques ; `users` les identités globales ; `memberships` les relations entre une personne et une boutique ; `store_settings` les réglages propres à une boutique.
- La migration `001_fondations` est un seul bloc transactionnel à exécuter une seule fois dans une base neuve dédiée aux essais. Elle enregistre sa version. Les futures migrations seront versionnées et appliquées séparément avec des contrôles de compatibilité et de retour arrière.
- Le rôle **administrateur/migration** possède les objets ; il n'est pas utilisé par le serveur applicatif. Sur Neon, les rôles créés dans l'interface, l'API ou la CLI peuvent appartenir à `neon_superuser` et contourner la RLS.
- `fasostore_app` est créé en SQL, non propriétaire, non superuser, sans `BYPASSRLS`, `CREATEROLE`, `CREATEDB` ni appartenance à d'autres rôles. Il n'a pas accès à `users` et ne peut pas `TRUNCATE` les tables concernées.
- Les tables boutiques utilisent `ENABLE` et `FORCE ROW LEVEL SECURITY`. Sans contexte, elles ne montrent aucune ligne. Les règles `USING` et `WITH CHECK` protègent lectures et écritures de `store_settings`.
- `withTenant` vérifie le rôle, ouvre une transaction et définit le tenant avec `set_config(..., true)` sur la même connexion ; rollback et exclusion de la connexion en cas d'erreur. Cela est compatible avec une mutualisation en mode transaction, sans `SET` persistant.
- Les nouvelles tables métier devront porter une clé `tenant_id` non nulle et utiliser des clés étrangères composites incluant le tenant quand une relation pourrait croiser deux boutiques.

**Limite fondamentale :** le rôle applicatif peut lui-même choisir la valeur du contexte PostgreSQL. La RLS protège contre certaines erreurs de requête, mais ne prouve pas qu'un utilisateur a le droit de choisir ce tenant. Avant toute route métier, la phase 3 doit authentifier la personne, résoudre la boutique et vérifier appartenance **et** permission côté serveur. Un paramètre, slug ou en-tête du navigateur ne constitue jamais une autorisation. Aucun CRUD boutique n'est exposé en phase 2.

Les tests locaux utilisent deux boutiques synthétiques, un rôle applicatif réel et un rôle d'administration distinct. Le test SQL prévu pour Neon utilise `SET LOCAL ROLE` depuis l'administrateur avec des données et un grant temporaires annulés. La connexion réelle avec le rôle limité sera vérifiée séparément via l'API après configuration ; le test SQL n'est pas une authentification par mot de passe.

## 3. Cible future

Sessions, MFA, audit, administration et boutiques ; catalogue, stocks, clients, commandes et paiements ; livraisons, abonnements et stockage objet. Les montants doivent être stockés en unités minimales entières avec devise explicite. Webhooks : point d'entrée limité, octets bruts, signatures, anti-rejeu et idempotence. Les prestataires et leur couverture géographique seront vérifiés avant activation.

Les plans gratuits sont adaptés aux essais et ne remplacent pas des sauvegardes restaurables, une disponibilité contractuelle, des limites d'abus distribuées, une revue de sécurité ou des tests de charge.
