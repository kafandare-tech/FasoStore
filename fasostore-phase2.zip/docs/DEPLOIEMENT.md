# Déploiement — aperçu et cible commerciale

## Aperçu existant

La phase 1 a été déployée à <https://fasostore.onrender.com/> sur un service Render de test. Le dépôt GitHub public contient l'archive `fasostore-phase1 (2).zip`. Les deux processus Next.js et Fastify s'exécutent dans ce service ; ceci n'est pas une architecture commerciale entièrement séparée.

Pour la phase 2, **ne pas supprimer l'archive phase 1** : déposer la nouvelle archive, vérifier son nom exact puis remplacer seulement la Build Command. Conserver la Start Command et la configuration Node 24. Les étapes complètes sans terminal et la procédure de retour arrière sont dans [GUIDE_ANDROID_PHASE2.md](GUIDE_ANDROID_PHASE2.md). N'introduire aucun mot de passe dans GitHub, les commandes ou les captures.

Les migrations ne sont pas exécutées au démarrage ou pendant la compilation Render. Elles sont exécutées **séparément** par l'administrateur dans la base de test. C'est volontaire : le service web ne reçoit pas les privilèges de migration. La commande pré-déploiement Render peut nécessiter une offre payante ; une vraie stratégie CI/CD et des migrations rétrocompatibles seront conçues avant production.

Variables privées dans Render après préparation de la base : `FASO_DB_HOST`, `FASO_DB_NAME`, `FASO_DB_PASSWORD`. L'utilisateur PostgreSQL est fixé au rôle limité `fasostore_app` ; il ne faut jamais utiliser le rôle propriétaire. Le navigateur ne reçoit pas ces variables.

## Avant ouverture commerciale

1. Versionner individuellement les fichiers dans un dépôt privé et activer la CI ; l'archive ZIP publique est un moyen temporaire et les workflows qu'elle contient ne sont pas automatiquement actifs.
2. Déployer Next.js et l'API comme services séparés, avec réseau privé/TLS et secrets limités à chaque service. Adapter `API_INTERNAL_URL` à l'adresse interne réelle ; `localhost` ne relie pas deux services séparés.
3. Configurer PostgreSQL, stockage, sauvegardes chiffrées et vérification de restauration, alertes et métriques ; choisir les plans après vérification des coûts et régions.
4. Terminer authentification, permissions, MFA, CSRF, limitation distribuée, audit de sécurité, flux d'achat et paiement en environnement d'essai.
5. Tester montée en charge, exploitabilité et reprise avant toute ouverture. Les offres gratuites ne garantissent ni disponibilité commerciale ni sauvegardes suffisantes.
