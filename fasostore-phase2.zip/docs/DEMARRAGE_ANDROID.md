# Démarrer FasoStore depuis Android

La phase 1 est déjà en ligne. Pour la phase 2, utiliser le [guide Android sans terminal](GUIDE_ANDROID_PHASE2.md). Celui-ci décrit Chrome, GitHub, Neon et Render pas à pas.

Le document `DEMARRAGE_ANDROID_PHASE1_HISTORIQUE.md` décrit une ancienne méthode Codespaces avec terminal. Il est conservé pour référence, mais **n'est pas nécessaire** au parcours actuel.
