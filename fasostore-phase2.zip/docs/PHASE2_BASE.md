# Phase 2 — détails techniques et vérifications

## Ce qui est livré

La migration `database/migrations/001_fondations.sql` s'exécute une seule fois sur une base de test neuve et dédiée, avec un rôle d'administration distinct. Elle crée `fasostore_app` par SQL avec un mot de passe initial généré côté serveur, inconnu et absent du script. Sur Neon, réinitialiser ce mot de passe depuis le menu du rôle avant de l'utiliser. Si le rôle SQL n'apparaît pas ou si la réinitialisation échoue, s'arrêter ; ne pas utiliser `neondb_owner` pour l'application.

Le bloc est atomique en PostgreSQL : si une instruction échoue, les changements sont annulés. Une collision de rôle provoque une erreur ; ne pas relancer ou supprimer des objets à l'aveugle. `003_controler_installation.sql` montre six booléens ; tous doivent être vrais. `002_verifier_isolation.sql` vérifie les accès A/B sous `SET LOCAL ROLE` avec deux boutiques synthétiques et annule tous les éléments temporaires même si le test réussit.

La connexion applicative est distincte : l'API se connecte effectivement comme `fasostore_app`, vérifie notamment le refus par défaut et la configuration, puis renvoie seulement un statut générique. Ses variables privées sont `FASO_DB_HOST`, `FASO_DB_NAME` et `FASO_DB_PASSWORD` ; TLS valide la CA et le nom DNS. Sur Neon, utiliser l'hôte **poolé** pour l'API et l'éditeur SQL/direct pour l'administration. Jamais de secret en front, dans Git ou dans le chat.

## Tests déjà exécutés sur une base locale

Sur PostgreSQL 17, avec un administrateur non-superuser doté de droits de migration et une connexion réelle distincte en tant que `fasostore_app` :

- tables vides hors contexte, lecture A et B isolée, modification croisée invisible et insertion croisée refusée ;
- accès à `users` et `TRUNCATE` refusés ; refus d'un rôle propriétaire ou membre d'un autre rôle ;
- contexte effacé après commit/rollback avec un pool limité à une connexion ;
- échec détecté quand une politique est volontairement rendue permissive ; atomicité de la migration contrôlée en provoquant une erreur ;
- TLS : CA et nom corrects acceptés ; certificat inconnu ou nom différent refusés.

Ces résultats portent sur le PostgreSQL local, **pas** sur une instance Neon encore inexistante. La suite `apps/api/test/database.integration.test.ts` est désactivée par défaut ; elle ne s'active qu'en local sur l'hôte `127.0.0.1` et la base jetable fixe `fasostore_test`, avec des identifiants de test fournis séparément. `npm run check` ne prétend pas l'exécuter.

## Limites avant la phase 3

Le rôle applicatif peut positionner le contexte de tenant de son choix : RLS seule ne constitue pas une autorisation. Les comptes, l'authentification et les permissions n'existent pas encore ; aucun endpoint n'expose de gestion de données de boutiques. Avant tout accès, il faudra une identité authentifiée, une appartenance et une autorisation vérifiées côté serveur, des tests négatifs supplémentaires et une stratégie d'accès limité aux identités globales.
