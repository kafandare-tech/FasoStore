// Browser -> same-origin Next.js -> internal API. Never return DB credentials.
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
const headers = { 'Cache-Control': 'no-store' };

export async function GET() {
  try {
    const configured = process.env.API_INTERNAL_URL;
    if (!configured && process.env.NODE_ENV === 'production') throw new Error('API non configurée');
    const origin = new URL(configured || 'http://127.0.0.1:4000');
    if (!['http:', 'https:'].includes(origin.protocol) || origin.username || origin.password || origin.search || origin.hash || !['', '/'].includes(origin.pathname)) {
      throw new Error('URL API invalide');
    }
    const response = await fetch(new URL('/healthz/database', origin), {
      cache: 'no-store', redirect: 'error', signal: AbortSignal.timeout(12000)
    });
    const body: unknown = await response.json();
    if (!body || typeof body !== 'object' || !('service' in body) || body.service !== 'fasostore-database' || !('status' in body)) throw new Error('Réponse invalide');
    if (response.ok && body.status === 'ok') return Response.json({ status: 'ok', checkedAt: new Date().toISOString() }, { headers });
    if (response.status === 503 && body.status === 'not_configured') return Response.json({ status: 'not_configured' }, { status: 503, headers });
    throw new Error('Base indisponible');
  } catch {
    return Response.json({ status: 'unavailable' }, { status: 503, headers });
  }
}
