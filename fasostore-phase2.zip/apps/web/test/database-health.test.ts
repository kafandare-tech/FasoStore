import { afterEach, describe, expect, it, vi } from 'vitest';
import { GET } from '../app/api/database-health/route';

const originalUrl = process.env.API_INTERNAL_URL;
afterEach(() => {
  vi.unstubAllGlobals();
  if (originalUrl === undefined) delete process.env.API_INTERNAL_URL;
  else process.env.API_INTERNAL_URL = originalUrl;
});

describe('Relais de santé PostgreSQL', () => {
  it('ne transmet que le statut et la date', async () => {
    process.env.API_INTERNAL_URL = 'http://127.0.0.1:4000';
    const fetchMock = vi.fn().mockResolvedValue(new Response(JSON.stringify({ service: 'fasostore-database', status: 'ok', password: 'secret-ne-pas-exposer' }), { status: 200 }));
    vi.stubGlobal('fetch', fetchMock);
    const response = await GET();
    const body = await response.json();
    expect(response.status).toBe(200);
    expect(body.status).toBe('ok');
    expect(typeof body.checkedAt).toBe('string');
    expect(JSON.stringify(body)).not.toContain('secret-ne-pas-exposer');
    expect(response.headers.get('cache-control')).toBe('no-store');
    expect(String(fetchMock.mock.calls[0][0])).toBe('http://127.0.0.1:4000/healthz/database');
  });
  it('distingue une base non configurée d’une panne', async () => {
    process.env.API_INTERNAL_URL = 'http://127.0.0.1:4000';
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response(JSON.stringify({ service: 'fasostore-database', status: 'not_configured' }), { status: 503 })));
    const response = await GET();
    expect(response.status).toBe(503);
    expect(await response.json()).toEqual({ status: 'not_configured' });
  });
  it('masque les erreurs et rejette les réponses incohérentes', async () => {
    process.env.API_INTERNAL_URL = 'http://127.0.0.1:4000';
    vi.stubGlobal('fetch', vi.fn().mockRejectedValue(new Error('détail privé')));
    let response = await GET();
    expect(response.status).toBe(503);
    expect(await response.json()).toEqual({ status: 'unavailable' });
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response(JSON.stringify({ service: 'autre', status: 'ok' }))));
    response = await GET();
    expect(response.status).toBe(503);
    process.env.API_INTERNAL_URL = 'file:///etc/passwd';
    expect((await GET()).status).toBe(503);
  });
});
