'use client';

import { Database, RefreshCw } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';

type State = { kind: 'checking' | 'ok' | 'not_configured' | 'unavailable'; checkedAt?: string };

export function LiveDatabase() {
  const [state, setState] = useState<State>({ kind: 'checking' });
  const check = useCallback(async () => {
    setState({ kind: 'checking' });
    try {
      const response = await fetch('/api/database-health', { cache: 'no-store', signal: AbortSignal.timeout(15000) });
      const body: unknown = await response.json();
      if (!body || typeof body !== 'object' || !('status' in body)) throw new Error();
      if (response.status === 503 && body.status === 'not_configured') {
        setState({ kind: 'not_configured', checkedAt: new Date().toISOString() });
        return;
      }
      if (!response.ok || body.status !== 'ok') throw new Error();
      const checkedAt = 'checkedAt' in body && typeof body.checkedAt === 'string' ? body.checkedAt : new Date().toISOString();
      setState({ kind: 'ok', checkedAt });
    } catch {
      setState({ kind: 'unavailable', checkedAt: new Date().toISOString() });
    }
  }, []);
  useEffect(() => { void check(); }, [check]);
  const labels: Record<State['kind'], string> = {
    checking: 'Vérification…', ok: 'Connectée', not_configured: 'Non configurée', unavailable: 'Indisponible'
  };
  const time = state.checkedAt ? new Intl.DateTimeFormat('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(new Date(state.checkedAt)) : '';
  return (
    <article className="status-card status-database">
      <div className="status-card-head">
        <span className="status-icon status-icon-amber"><Database size={19} aria-hidden="true" /></span>
        <button className="refresh-button" onClick={() => void check()} disabled={state.kind === 'checking'} type="button" aria-label="Actualiser l’état de la base de données" title="Actualiser l’état de la base de données">
          <RefreshCw size={16} className={state.kind === 'checking' ? 'spinning' : ''} aria-hidden="true" />
        </button>
      </div>
      <h3>Base de données</h3>
      <p>PostgreSQL et contrôles de base.</p>
      <div className={`state-label state-${state.kind}`} role="status" aria-live="polite"><span className="state-dot" />{labels[state.kind]}</div>
      <small className="check-time">{time ? `Vérifiée à ${time}` : 'Vérification en cours'}</small>
    </article>
  );
}
