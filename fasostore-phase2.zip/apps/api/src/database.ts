import pg, { type PoolClient, type PoolConfig } from 'pg';
import { z } from 'zod';

export type DatabaseStatus = 'ok' | 'not_configured' | 'unavailable';
export interface DatabaseService {
  health(): Promise<DatabaseStatus>;
  close(): Promise<void>;
}

const protectedTables = ['tenants', 'memberships', 'store_settings'];

/**
 * RLS is defence in depth. A role that can set this custom setting can choose any
 * tenant; before a real route uses withTenant, phase 3 MUST verify identity,
 * membership and permission on the server. There are no such routes in phase 2.
 */
async function assertRestrictedRuntime(client: PoolClient): Promise<void> {
  const result = await client.query<{
    limited_role: boolean; no_memberships: boolean; no_schema_create: boolean;
    no_user_access: boolean; tables_protected: boolean; clean_context: boolean;
    migration_present: boolean;
  }>(`
    SELECT
      r.rolname = 'fasostore_app' AND r.rolcanlogin AND NOT r.rolsuper
        AND NOT r.rolbypassrls AND NOT r.rolcreaterole AND NOT r.rolcreatedb
        AND NOT r.rolreplication AND NOT r.rolinherit AS limited_role,
      NOT EXISTS (SELECT 1 FROM pg_catalog.pg_auth_members m WHERE m.member = r.oid) AS no_memberships,
      NOT has_schema_privilege(current_user, 'fasostore', 'CREATE')
        AND NOT has_schema_privilege(current_user, 'public', 'CREATE') AS no_schema_create,
      NOT has_table_privilege(current_user, 'fasostore.users',
        'SELECT, INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER') AS no_user_access,
      (SELECT count(*) = 3 FROM pg_catalog.pg_class c
        JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
        WHERE n.nspname = 'fasostore' AND c.relname = ANY($1::text[])
          AND c.relkind = 'r' AND c.relrowsecurity AND c.relforcerowsecurity
          AND row_security_active(c.oid)
          AND NOT pg_has_role(current_user, c.relowner, 'MEMBER')
          AND NOT has_table_privilege(current_user, c.oid, 'TRUNCATE')) AS tables_protected,
      nullif(current_setting('fasostore.tenant_id', true), '') IS NULL AS clean_context,
      EXISTS(SELECT 1 FROM fasostore.schema_migrations WHERE version = '001_fondations') AS migration_present
    FROM pg_catalog.pg_roles r WHERE r.rolname = current_user
  `, [protectedTables]);
  const row = result.rows[0];
  if (!row || !Object.values(row).every((value) => value === true)) throw new Error('Runtime database safety check failed');

  // No tenant context must mean zero visible tenant rows, even when tables have data.
  const visibility = await client.query<{ denied: boolean }>(`
    SELECT NOT EXISTS (SELECT 1 FROM fasostore.tenants)
       AND NOT EXISTS (SELECT 1 FROM fasostore.memberships)
       AND NOT EXISTS (SELECT 1 FROM fasostore.store_settings) AS denied
  `);
  if (visibility.rows[0]?.denied !== true) throw new Error('Default-deny check failed');
}

export class PostgresDatabase implements DatabaseService {
  constructor(private readonly pool: pg.Pool) {
    // Prevent a disconnected idle client from crashing the API or logging credentials.
    this.pool.on('error', () => { /* the next health check reports unavailable */ });
  }

  async health(): Promise<DatabaseStatus> {
    try {
      await this.runTransaction(async (client) => { await assertRestrictedRuntime(client); });
      return 'ok';
    } catch {
      return 'unavailable';
    }
  }

  /** Internal building block ONLY; no public caller exists in phase 2. */
  async withTenant<T>(verifiedTenantId: string, operation: (client: PoolClient) => Promise<T>): Promise<T> {
    if (!z.uuid().safeParse(verifiedTenantId).success) throw new Error('Invalid tenant id');
    return this.runTransaction(async (client) => {
      await assertRestrictedRuntime(client);
      // Parameterized and LOCAL to this transaction; never a persistent SET.
      await client.query("SELECT set_config('fasostore.tenant_id', $1, true)", [verifiedTenantId]);
      return operation(client);
    });
  }

  private async runTransaction<T>(operation: (client: PoolClient) => Promise<T>): Promise<T> {
    const client = await this.pool.connect();
    let discard = false;
    try {
      await client.query('BEGIN');
      const result = await operation(client);
      await client.query('COMMIT');
      return result;
    } catch (error) {
      // An error could indicate an unsafe context or a broken connection. Always
      // discard the client after rollback rather than returning it to the pool.
      discard = true;
      try { await client.query('ROLLBACK'); } catch { /* discard below */ }
      throw error;
    } finally {
      client.release(discard);
    }
  }

  async close(): Promise<void> { await this.pool.end(); }
}

class NotConfiguredDatabase implements DatabaseService {
  constructor(private readonly status: 'not_configured' | 'unavailable') {}
  async health(): Promise<DatabaseStatus> { return this.status; }
  async close(): Promise<void> { /* no pool */ }
}

/** Server-only environment variables, with authenticated TLS (CA and hostname). */
export function createDatabase(env: NodeJS.ProcessEnv = process.env): DatabaseService {
  const values = [env.FASO_DB_HOST, env.FASO_DB_NAME, env.FASO_DB_PASSWORD];
  if (values.every((value) => !value)) return new NotConfiguredDatabase('not_configured');
  // Never accept a process-wide TLS verification bypass, even in an accidental deploy.
  if (env.NODE_TLS_REJECT_UNAUTHORIZED === '0') return new NotConfiguredDatabase('unavailable');
  const validHost = z.string().min(1).max(253).regex(/^[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?$/).safeParse(env.FASO_DB_HOST);
  const validDatabase = z.string().min(1).max(63).regex(/^[A-Za-z0-9_]+$/).safeParse(env.FASO_DB_NAME);
  const validPassword = z.string().min(1).max(512).safeParse(env.FASO_DB_PASSWORD);
  if (!validHost.success || !validDatabase.success || !validPassword.success) return new NotConfiguredDatabase('unavailable');
  const config: PoolConfig = {
    host: validHost.data,
    database: validDatabase.data,
    user: 'fasostore_app',
    password: validPassword.data,
    port: 5432,
    ssl: { rejectUnauthorized: true, servername: validHost.data },
    enableChannelBinding: true,
    max: 4,
    connectionTimeoutMillis: 10000,
    idleTimeoutMillis: 10000,
    query_timeout: 6000,
    statement_timeout: 5000,
    application_name: 'fasostore-api'
  };
  return new PostgresDatabase(new pg.Pool(config));
}
