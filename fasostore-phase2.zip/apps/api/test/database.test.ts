import { afterEach, describe, expect, it, vi } from 'vitest';
import { createApp } from '../src/app.js';
import { createDatabase, type DatabaseService } from '../src/database.js';

const apps: ReturnType<typeof createApp>[] = [];
afterEach(async () => { await Promise.all(apps.splice(0).map((app) => app.close())); });

function mocked(status: 'ok' | 'not_configured' | 'unavailable') {
  const database: DatabaseService = { health: vi.fn().mockResolvedValue(status), close: vi.fn().mockResolvedValue(undefined) };
  const app = createApp({ logger: false, database });
  apps.push(app);
  return { app, database };
}

describe('Santé de la base de données', () => {
  it('signale l’état vérifié sans exposer de détail interne', async () => {
    const { app } = mocked('ok');
    const response = await app.inject({ method: 'GET', url: '/healthz/database' });
    expect(response.statusCode).toBe(200);
    expect(response.json()).toEqual({ service: 'fasostore-database', status: 'ok' });
    expect(response.headers['cache-control']).toBe('no-store');
  });
  it.each(['not_configured', 'unavailable'] as const)('renvoie 503 pour %s', async (status) => {
    const { app } = mocked(status);
    const response = await app.inject({ method: 'GET', url: '/healthz/database' });
    expect(response.statusCode).toBe(503);
    expect(response.json()).toEqual({ service: 'fasostore-database', status });
  });
  it('ne crée pas de pool si la configuration manque ou est partielle', async () => {
    const empty = createDatabase({});
    expect(await empty.health()).toBe('not_configured');
    const partial = createDatabase({ FASO_DB_HOST: 'host.example' });
    expect(await partial.health()).toBe('unavailable');
    await empty.close();
    await partial.close();
  });
  it('refuse une configuration de nom de serveur ou de base invalide', async () => {
    expect(await createDatabase({ FASO_DB_HOST: 'bad host', FASO_DB_NAME: 'db', FASO_DB_PASSWORD: 'secret' }).health()).toBe('unavailable');
    expect(await createDatabase({ FASO_DB_HOST: 'host.example', FASO_DB_NAME: 'db/evil', FASO_DB_PASSWORD: 'secret' }).health()).toBe('unavailable');
    expect(await createDatabase({ FASO_DB_HOST: 'host.example', FASO_DB_NAME: 'db', FASO_DB_PASSWORD: 'secret', NODE_TLS_REJECT_UNAUTHORIZED: '0' }).health()).toBe('unavailable');
  });
});
