import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import pg from 'pg';
import { PostgresDatabase } from '../src/database.js';

// This suite intentionally only targets a disposable local database, never cloud.
// Ordinary npm checks skip it; run separately with FASO_RUN_LOCAL_PG_TESTS=1.
const integration = process.env.FASO_RUN_LOCAL_PG_TESTS === '1' ? describe : describe.skip;
const TENANT_A = '11111111-1111-4111-8111-111111111111';
const TENANT_B = '22222222-2222-4222-8222-222222222222';
const USER_A = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
const USER_B = 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb';
const local = { host: '127.0.0.1', port: 5432, database: 'fasostore_test', ssl: false };
const admin = new pg.Pool({ ...local, user: 'fasostore_test_admin', password: process.env.FASO_TEST_ADMIN_PASSWORD, max: 1 });
const runtime = new pg.Pool({ ...local, user: 'fasostore_app', password: process.env.FASO_TEST_APP_PASSWORD, max: 1 });
const db = new PostgresDatabase(runtime);

integration('PostgreSQL réel : cloisonnement multi-boutique', () => {
  beforeAll(async () => {
    if (!process.env.FASO_TEST_ADMIN_PASSWORD || !process.env.FASO_TEST_APP_PASSWORD) throw new Error('Missing local test passwords');
    await admin.query("INSERT INTO fasostore.tenants(id, name, slug) VALUES ($1,'Boutique A','test-boutique-a'),($2,'Boutique B','test-boutique-b')", [TENANT_A, TENANT_B]);
    await admin.query("INSERT INTO fasostore.users(id, email) VALUES ($1,'a@example.invalid'),($2,'b@example.invalid')", [USER_A, USER_B]);
    await admin.query("INSERT INTO fasostore.memberships(tenant_id,user_id,member_role) VALUES ($1,$2,'owner'),($3,$4,'owner')", [TENANT_A, USER_A, TENANT_B, USER_B]);
    await admin.query("INSERT INTO fasostore.store_settings(tenant_id,store_title) VALUES ($1,'Titre A'),($2,'Titre B')", [TENANT_A, TENANT_B]);
  });
  afterAll(async () => {
    await admin.query('DELETE FROM fasostore.tenants WHERE id = ANY($1::uuid[])', [[TENANT_A, TENANT_B]]);
    await admin.query('DELETE FROM fasostore.users WHERE id = ANY($1::uuid[])', [[USER_A, USER_B]]);
    await db.close();
    await admin.end();
  });
  it('valide le rôle limité, les migrations et le refus par défaut', async () => {
    expect(await db.health()).toBe('ok');
    for (const table of ['tenants', 'memberships', 'store_settings']) {
      const rows = await runtime.query(`SELECT * FROM fasostore.${table}`);
      expect(rows.rowCount).toBe(0);
    }
    await expect(runtime.query('SELECT * FROM fasostore.users')).rejects.toMatchObject({ code: '42501' });
    await expect(runtime.query('TRUNCATE fasostore.store_settings')).rejects.toMatchObject({ code: '42501' });
  });
  it('ne laisse A ni lire ni modifier les données de B', async () => {
    const seen = await db.withTenant(TENANT_A, async (client) => {
      const tenants = await client.query('SELECT id FROM fasostore.tenants ORDER BY id');
      const settings = await client.query('SELECT tenant_id FROM fasostore.store_settings ORDER BY tenant_id');
      const members = await client.query('SELECT tenant_id FROM fasostore.memberships ORDER BY tenant_id');
      const stolen = await client.query("UPDATE fasostore.store_settings SET store_title='Vol' WHERE tenant_id=$1", [TENANT_B]);
      return { tenants: tenants.rows, settings: settings.rows, members: members.rows, touched: stolen.rowCount };
    });
    expect(seen).toEqual({ tenants: [{ id: TENANT_A }], settings: [{ tenant_id: TENANT_A }], members: [{ tenant_id: TENANT_A }], touched: 0 });
    await expect(db.withTenant(TENANT_A, (c) => c.query("UPDATE fasostore.store_settings SET tenant_id=$1 WHERE tenant_id=$2", [TENANT_B, TENANT_A]))).rejects.toMatchObject({ code: '42501' });
    await expect(db.withTenant(TENANT_A, (c) => c.query("INSERT INTO fasostore.store_settings(tenant_id,store_title) VALUES ($1,'Intrusion')", [TENANT_B]))).rejects.toMatchObject({ code: '42501' });
    const b = await db.withTenant(TENANT_B, (c) => c.query('SELECT tenant_id,store_title FROM fasostore.store_settings'));
    expect(b.rows).toEqual([{ tenant_id: TENANT_B, store_title: 'Titre B' }]);
  });
  it('efface le contexte après COMMIT et ROLLBACK, même avec un pool de taille 1', async () => {
    await db.withTenant(TENANT_A, (c) => c.query('SELECT 1'));
    const clean = await runtime.query("SELECT nullif(current_setting('fasostore.tenant_id',true),'') IS NULL AS clean");
    expect(clean.rows[0].clean).toBe(true);
    await expect(db.withTenant(TENANT_A, async (client) => {
      await client.query("UPDATE fasostore.store_settings SET store_title='À annuler' WHERE tenant_id=$1", [TENANT_A]);
      throw new Error('erreur volontaire');
    })).rejects.toThrow('erreur volontaire');
    expect(await db.health()).toBe('ok');
    const a = await db.withTenant(TENANT_A, (c) => c.query('SELECT store_title FROM fasostore.store_settings'));
    expect(a.rows).toEqual([{ store_title: 'Titre A' }]);
    const b = await db.withTenant(TENANT_B, (c) => c.query('SELECT tenant_id FROM fasostore.store_settings'));
    expect(b.rows).toEqual([{ tenant_id: TENANT_B }]);
    await expect(db.withTenant('pas-un-uuid', async () => 1)).rejects.toThrow('Invalid tenant id');
  });
  it('refuse un rôle propriétaire ou privilégié', async () => {
    const unsafe = new PostgresDatabase(new pg.Pool({ ...local, user: 'fasostore_test_admin', password: process.env.FASO_TEST_ADMIN_PASSWORD, max: 1 }));
    try {
      expect(await unsafe.health()).toBe('unavailable');
      await expect(unsafe.withTenant(TENANT_A, (c) => c.query('SELECT 1'))).rejects.toThrow();
    } finally { await unsafe.close(); }
  });
  it('refuse un rôle applicatif membre d’un autre rôle', async () => {
    await admin.query('CREATE ROLE fasostore_test_group NOLOGIN');
    try {
      await admin.query('GRANT fasostore_test_group TO fasostore_app');
      expect(await db.health()).toBe('unavailable');
    } finally {
      await admin.query('REVOKE fasostore_test_group FROM fasostore_app');
      await admin.query('DROP ROLE fasostore_test_group');
    }
    expect(await db.health()).toBe('ok');
  });
  it('détecte une politique accidentellement ouverte quand des données existent', async () => {
    await admin.query('ALTER POLICY settings_isolation ON fasostore.store_settings USING (true) WITH CHECK (true)');
    try {
      expect(await db.health()).toBe('unavailable');
    } finally {
      await admin.query("ALTER POLICY settings_isolation ON fasostore.store_settings USING (tenant_id = nullif(current_setting('fasostore.tenant_id', true), '')::uuid) WITH CHECK (tenant_id = nullif(current_setting('fasostore.tenant_id', true), '')::uuid)");
    }
    expect(await db.health()).toBe('ok');
  });
});
